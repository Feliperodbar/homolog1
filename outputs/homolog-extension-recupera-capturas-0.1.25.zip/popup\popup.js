// src/shared/constants.ts
var SCREENSHOT = {
  FORMAT: "image/jpeg",
  QUALITY: 0.82,
  MAX_WIDTH_PX: 1920,
  TIMEOUT_MS: 4e3,
  // captureVisibleTab possui limite de chamadas no Chromium. Mantemos margem
  // acima de 500 ms para não perder capturas por excesso de frequência.
  MIN_INTERVAL_BETWEEN_CAPTURES_MS: 525,
  POINTER_MARKER_ID: "__homolog_click_marker__",
  POINTER_MARKER_RADIUS_PX: 18,
  POINTER_MARKER_DURATION_MS: 1200,
  MAX_STEPS_IN_STORAGE: 200,
  MAX_DATA_URL_LENGTH: 4 * 1024 * 1024
};
var HOMOLOG_PANEL_DEFAULT_URL = "http://localhost:5173/";
var RESTRICTED_URL_PATTERNS = [
  /^chrome:\/\//i,
  /^edge:\/\//i,
  /^about:/i,
  /^view-source:/i,
  /^devtools:/i,
  /^chrome-search:/i,
  /^chrome-untrusted:/i
];
var RESTRICTED_HOSTNAMES = [
  "chrome.google.com",
  "chromewebstore.google.com",
  "microsoftedge.microsoft.com",
  "addons.mozilla.org",
  "addons.opera.com",
  "addons.chromium.org"
];
var STATE_LABELS = {
  idle: "Pronto",
  recording: "Gravando",
  paused: "Pausado",
  finalized: "Finalizado"
};

// src/shared/restrictedUrls.ts
function isRestrictedUrl(url) {
  if (!url || typeof url !== "string") {
    return { restricted: true, reason: "internal" };
  }
  for (const pattern of RESTRICTED_URL_PATTERNS) {
    if (pattern.test(url)) {
      return { restricted: true, reason: "internal", pattern };
    }
  }
  try {
    const u = new URL(url);
    const host = u.hostname.toLowerCase();
    for (const h of RESTRICTED_HOSTNAMES) {
      if (host === h || host.endsWith(`.${h}`)) {
        return { restricted: true, reason: "webstore", hostname: h };
      }
    }
  } catch {
    return { restricted: true, reason: "internal" };
  }
  return { restricted: false };
}

// src/popup/popup.ts
var els = {
  start: document.getElementById("startBtn"),
  pause: document.getElementById("pauseBtn"),
  resume: document.getElementById("resumeBtn"),
  finalize: document.getElementById("finalizeBtn"),
  openPanel: document.getElementById("openPanelBtn"),
  statusPill: document.getElementById("statusPill"),
  stepCount: document.getElementById("stepCountBadge"),
  sessionId: document.getElementById("sessionId"),
  startedAt: document.getElementById("startedAt"),
  tabInfo: document.getElementById("tabInfo"),
  restrictedBanner: document.getElementById("restrictedBanner"),
  restrictedReason: document.getElementById("restrictedReason"),
  errorBox: document.getElementById("errorBox"),
  interactionCard: document.getElementById("interactionCard"),
  interactionTag: document.getElementById("interactionTag"),
  interactionTime: document.getElementById("interactionTime"),
  interactionText: document.getElementById("interactionText"),
  interactionSelector: document.getElementById("interactionSelector"),
  interactionCoords: document.getElementById("interactionCoords"),
  interactionSource: document.getElementById("interactionSource"),
  stepsCard: document.getElementById("stepsCard"),
  stepsHeaderCount: document.getElementById("stepsHeaderCount"),
  stepsList: document.getElementById("stepsList")
};
function formatDateTime(ts) {
  if (!ts) return "—";
  try {
    const d = new Date(ts);
    return d.toLocaleString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });
  } catch {
    return "—";
  }
}
function shortSessionId(id) {
  if (!id) return "—";
  const head = id.slice(0, 8);
  const tail = id.slice(-5);
  return `${head}...${tail}`;
}
function setError(msg) {
  if (!els.errorBox) return;
  if (!msg) {
    els.errorBox.textContent = "";
    els.errorBox.classList.add("hidden");
    return;
  }
  els.errorBox.textContent = msg;
  els.errorBox.classList.remove("hidden");
}
async function sendMessage(msg) {
  try {
    const r = await chrome.runtime.sendMessage(msg);
    if (!r) return { ok: false, error: "sem resposta do service worker" };
    return r;
  } catch (e) {
    return {
      ok: false,
      error: e instanceof Error ? e.message : String(e)
    };
  }
}
function updateInteractionView(interaction) {
  if (!els.interactionCard) return;
  if (!interaction) {
    els.interactionCard.classList.add("hidden");
    return;
  }
  els.interactionCard.classList.remove("hidden");
  if (els.interactionTag) {
    els.interactionTag.textContent = interaction.target.tagName || "?";
  }
  if (els.interactionTime) {
    els.interactionTime.textContent = formatDateTime(interaction.timestamp);
  }
  if (els.interactionText) {
    const t = interaction.target.visibleText || interaction.target.accessibleName || "—";
    els.interactionText.textContent = t;
    els.interactionText.title = t;
  }
  if (els.interactionSelector) {
    els.interactionSelector.textContent = interaction.stableSelector || "—";
    els.interactionSelector.title = interaction.stableSelector || "";
  }
  if (els.interactionCoords) {
    els.interactionCoords.textContent = `(${Math.round(interaction.viewportPoint.x)}, ${Math.round(
      interaction.viewportPoint.y
    )})`;
  }
  if (els.interactionSource) {
    const map = {
      mouse: "Mouse",
      touch: "Toque",
      pen: "Caneta",
      unknown: "—"
    };
    els.interactionSource.textContent = map[interaction.inputSource] ?? interaction.inputSource;
  }
}
function updateStepsView(steps) {
  if (!els.stepsCard || !els.stepsList) return;
  const arr = Array.isArray(steps) ? steps.slice().sort((a, b) => b.sequence - a.sequence).slice(0, 5) : [];
  if (arr.length === 0) {
    els.stepsCard.classList.add("hidden");
    els.stepsList.innerHTML = "";
    if (els.stepsHeaderCount) els.stepsHeaderCount.textContent = "0";
    return;
  }
  els.stepsCard.classList.remove("hidden");
  if (els.stepsHeaderCount) els.stepsHeaderCount.textContent = String(arr.length);
  const frag = document.createDocumentFragment();
  for (const step of arr) {
    const li = document.createElement("li");
    li.className = "step-item";
    const seq = document.createElement("div");
    seq.className = "step-seq";
    seq.textContent = `#${step.sequence}`;
    const thumb = document.createElement("div");
    thumb.className = "step-thumb";
    if (step.screenshotDataUrl && step.screenshotDataUrl.length > 64) {
      thumb.style.backgroundImage = `url("${step.screenshotDataUrl}")`;
    } else {
      thumb.classList.add("empty");
      thumb.textContent = "sem img";
    }
    const info = document.createElement("div");
    info.className = "step-info";
    const desc = document.createElement("div");
    desc.className = "step-desc";
    desc.textContent = step.description || "—";
    desc.title = step.description || "";
    const meta = document.createElement("div");
    meta.className = "step-meta";
    const url = (typeof step.url === "string" ? step.url : "").slice(0, 120);
    const ts = formatDateTime(step.timestamp);
    meta.textContent = url ? `${ts} · ${url}` : ts;
    info.appendChild(desc);
    info.appendChild(meta);
    li.appendChild(seq);
    li.appendChild(thumb);
    li.appendChild(info);
    frag.appendChild(li);
  }
  els.stepsList.innerHTML = "";
  els.stepsList.appendChild(frag);
}
function updateView(session, restricted, interaction) {
  if (!els.statusPill) return;
  const stateLabel = STATE_LABELS[session.state] ?? session.state;
  els.statusPill.textContent = stateLabel;
  els.statusPill.className = `pill pill-${session.state}`;
  if (els.stepCount) {
    els.stepCount.textContent = String(session.stepCount ?? 0);
  }
  if (els.sessionId) {
    els.sessionId.textContent = shortSessionId(session.sessionId);
    els.sessionId.title = session.sessionId ?? "";
  }
  if (els.startedAt) {
    els.startedAt.textContent = formatDateTime(session.startedAt);
  }
  if (els.tabInfo) {
    els.tabInfo.textContent = typeof session.tabId === "number" ? `Aba #${session.tabId}` : "Nenhuma";
  }
  if (els.start) {
    els.start.disabled = session.state !== "idle" && session.state !== "finalized";
  }
  if (els.pause) {
    els.pause.disabled = session.state !== "recording";
  }
  if (els.resume) {
    els.resume.disabled = session.state !== "paused";
  }
  if (els.finalize) {
    els.finalize.disabled = session.state !== "recording" && session.state !== "paused";
  }
  if (els.restrictedBanner) {
    if (restricted) els.restrictedBanner.classList.remove("hidden");
    else els.restrictedBanner.classList.add("hidden");
  }
  updateInteractionView(interaction ?? null);
}
async function getCurrentTabInfo() {
  try {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });
    const r = isRestrictedUrl(tab?.url);
    return {
      restricted: r.restricted,
      tabId: tab?.id ?? null,
      url: tab?.url ?? null,
      title: tab?.title ?? null
    };
  } catch {
    return { restricted: false, tabId: null, url: null, title: null };
  }
}
async function refresh() {
  const [tabInfo, stateResp, stepsResp] = await Promise.all([
    getCurrentTabInfo(),
    sendMessage({ type: "GET_STATE" }),
    sendMessage({ type: "__LIST_STEPS__" })
  ]);
  if (!stateResp.ok || !stateResp.state) {
    setError(`Erro ao ler estado: ${stateResp.error ?? "desconhecido"}`);
    return;
  }
  const steps = stepsResp.ok ? stepsResp.steps : void 0;
  setError(null);
  updateView(stateResp.state, tabInfo.restricted, stateResp.lastInteraction);
  updateStepsView(steps ?? null);
}
async function action(type) {
  setError(null);
  const r = await sendMessage({ type });
  if (!r.ok) {
    setError(`Erro: ${r.error ?? "desconhecido"}`);
  }
  await refresh();
}
async function openPanel() {
  try {
    const url = new URL(HOMOLOG_PANEL_DEFAULT_URL);
    url.searchParams.set("homologExtensionId", chrome.runtime.id);
    await chrome.tabs.create({ url: url.toString() });
  } catch (e) {
    setError(`Não foi possível abrir o painel: ${e instanceof Error ? e.message : String(e)}`);
  }
}
function bindButtons() {
  els.start?.addEventListener("click", () => void action("START"));
  els.pause?.addEventListener("click", () => void action("PAUSE"));
  els.resume?.addEventListener("click", () => void action("RESUME"));
  els.finalize?.addEventListener("click", () => void action("FINALIZE"));
  els.openPanel?.addEventListener("click", () => void openPanel());
  chrome.storage.onChanged.addListener((_changes, areaName) => {
    if (areaName === "local") {
      void refresh();
    }
  });
  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg?.type === "__STATE_CHANGED__") {
        void refresh();
      } else if (msg?.type === "__INTERACTION_RECORDED__") {
        const interaction = msg?.payload?.interaction;
        if (els.interactionCard) {
          updateInteractionView(interaction ?? null);
        }
        if (els.stepCount && msg?.payload?.session?.stepCount !== void 0) {
          els.stepCount.textContent = String(msg.payload.session.stepCount);
        }
      } else if (msg?.type === "__STEP_RECORDED__") {
        void refresh();
      }
    });
  } catch {
  }
  window.addEventListener("focus", () => void refresh());
}
if (typeof document !== "undefined") {
  bindButtons();
  void refresh();
}
//# sourceMappingURL=popup.js.map
