"use strict";
(() => {
  // src/shared/constants.ts
  var STORAGE_KEY_RECORDING = "homolog_recording_v1";
  var CHROME_MESSAGE_TIMEOUT_MS = 1500;
  var SCREENSHOT = {
    FORMAT: "image/jpeg",
    QUALITY: 0.82,
    MAX_WIDTH_PX: 1920,
    TIMEOUT_MS: 4e3,
    // captureVisibleTab possui limite de chamadas no Chromium. Mantemos margem
    // acima de 500 ms para não perder capturas por excesso de frequência.
    MIN_INTERVAL_BETWEEN_CAPTURES_MS: 525,
    POINTER_MARKER_ID: "__homolog_click_marker__",
    POINTER_MARKER_RADIUS_PX: 18,
    POINTER_MARKER_DURATION_MS: 1200,
    MAX_STEPS_IN_STORAGE: 200,
    MAX_DATA_URL_LENGTH: 4 * 1024 * 1024
  };
  var RESTRICTED_URL_PATTERNS = [
    /^chrome:\/\//i,
    /^edge:\/\//i,
    /^about:/i,
    /^view-source:/i,
    /^devtools:/i,
    /^chrome-search:/i,
    /^chrome-untrusted:/i
  ];
  var RESTRICTED_HOSTNAMES = [
    "chrome.google.com",
    "chromewebstore.google.com",
    "microsoftedge.microsoft.com",
    "addons.mozilla.org",
    "addons.opera.com",
    "addons.chromium.org"
  ];
  var RESTRICTED_PAGE_REASONS = {
    internal: "Esta é uma página interna do navegador. A gravação de passos não é permitida aqui por motivos de segurança.",
    webstore: "Esta página é uma loja de extensões. Por restrições do navegador, extensões não funcionam aqui."
  };
  var DEDUPLICATION = {
    INTERACTION_WINDOW_MS: 250,
    POSITION_TOLERANCE_PX: 6,
    DOUBLE_CLICK_WINDOW_MS: 350,
    TEXT_MAX_LENGTH: 240,
    SELECTOR_MAX_LENGTH: 320
  };
  var SENSITIVE_AUTOCOMPLETE_TOKENS = [
    "password",
    "new-password",
    "current-password",
    "cc-number",
    "cc-csc",
    "cc-cvv",
    "cc-exp",
    "cc-exp-month",
    "cc-exp-year",
    "off"
  ];
  var SENSITIVE_INPUT_TYPES = ["password"];

  // src/shared/restrictedUrls.ts
  function isRestrictedUrl(url) {
    if (!url || typeof url !== "string") {
      return { restricted: true, reason: "internal" };
    }
    for (const pattern of RESTRICTED_URL_PATTERNS) {
      if (pattern.test(url)) {
        return { restricted: true, reason: "internal", pattern };
      }
    }
    try {
      const u = new URL(url);
      const host = u.hostname.toLowerCase();
      for (const h of RESTRICTED_HOSTNAMES) {
        if (host === h || host.endsWith(`.${h}`)) {
          return { restricted: true, reason: "webstore", hostname: h };
        }
      }
    } catch {
      return { restricted: true, reason: "internal" };
    }
    return { restricted: false };
  }

  // src/shared/accessibleName.ts
  function isElement(v) {
    return !!v && typeof v === "object" && "nodeType" in v && v.nodeType === 1;
  }
  function getAttr(el, name) {
    try {
      const v = el.getAttribute(name);
      return typeof v === "string" ? v : null;
    } catch {
      return null;
    }
  }
  function normalizeText(s, max = DEDUPLICATION.TEXT_MAX_LENGTH) {
    if (typeof s !== "string") return "";
    const trimmed = s.replace(/\s+/g, " ").trim();
    if (trimmed.length <= max) return trimmed;
    return `${trimmed.slice(0, max - 1)}…`;
  }
  function elementText(el) {
    try {
      if ("innerText" in el && typeof el.innerText === "string") {
        return normalizeText(el.innerText);
      }
    } catch {
    }
    try {
      return normalizeText(el.textContent ?? "");
    } catch {
      return "";
    }
  }
  function resolveLabelByFor(root, id) {
    if (!id || !root) return null;
    try {
      if (typeof root.querySelectorAll === "function") {
        const labels = root.querySelectorAll?.("label");
        if (labels) {
          for (let i = 0; i < labels.length; i += 1) {
            const l = labels[i];
            if (l.getAttribute("for") === id) {
              const txt = elementText(l);
              if (txt) return txt;
            }
          }
        }
      }
    } catch {
    }
    try {
      const doc = typeof document !== "undefined" ? document : root.ownerDocument;
      if (doc && typeof doc.getElementsByName === "function") {
        const candidates = doc.querySelectorAll?.(
          `label[for="${id.replace(/"/g, '\\"')}"]`
        );
        if (candidates && candidates.length > 0) {
          const txt = elementText(candidates[0]);
          if (txt) return txt;
        }
      }
    } catch {
    }
    return null;
  }
  function getEnclosingLabel(el) {
    try {
      let cur = el;
      for (let i = 0; i < 6 && cur; i += 1) {
        if (cur.tagName === "LABEL") return cur;
        cur = cur.parentElement ?? null;
      }
      return null;
    } catch {
      return null;
    }
  }
  function computeAccessibleName(input) {
    if (!isElement(input)) return "";
    const el = input;
    const doc = typeof document !== "undefined" ? document : el.ownerDocument ?? void 0;
    const labelledBy = getAttr(el, "aria-labelledby");
    if (labelledBy) {
      const ids = labelledBy.split(/\s+/).filter(Boolean);
      if (ids.length > 0 && doc) {
        const parts = ids.map((id) => doc.getElementById?.(id)).filter((n) => !!n).map((n) => elementText(n)).filter((s) => s.length > 0);
        if (parts.length > 0) return normalizeText(parts.join(" "));
      }
    }
    const ariaLabel = getAttr(el, "aria-label");
    if (ariaLabel) return normalizeText(ariaLabel);
    const forLabel = resolveLabelByFor(doc, getAttr(el, "id"));
    if (forLabel) return normalizeText(forLabel);
    const enclosure = getEnclosingLabel(el);
    if (enclosure) {
      const labelText = elementText(enclosure).replace(elementText(el), "").trim();
      if (labelText) return normalizeText(labelText);
    }
    switch (el.tagName.toLowerCase()) {
      case "input":
      case "textarea": {
        const placeholder = getAttr(el, "placeholder");
        if (placeholder) return normalizeText(placeholder);
        break;
      }
      case "img":
      case "area": {
        const alt = getAttr(el, "alt");
        if (alt) return normalizeText(alt);
        break;
      }
    }
    switch (el.tagName.toLowerCase()) {
      case "button":
      case "a":
      case "label":
      case "h1":
      case "h2":
      case "h3":
      case "h4":
      case "h5":
      case "h6":
      case "span":
      case "div":
      case "li":
      case "td":
      case "th":
      case "option":
      case "summary": {
        const txt = elementText(el);
        if (txt) return txt;
        break;
      }
    }
    const title = getAttr(el, "title");
    if (title) return normalizeText(title);
    if (el.tagName.toLowerCase() === "button") {
      const val = getAttr(el, "value");
      if (val) return normalizeText(val);
    }
    return "";
  }
  function extractVisibleText(input, sensitive = false) {
    if (!isElement(input)) return "";
    if (sensitive) return "";
    const el = input;
    switch (el.tagName.toLowerCase()) {
      case "input":
      case "select":
      case "textarea": {
        const txt = elementText(el);
        return txt;
      }
      default: {
        return elementText(el);
      }
    }
  }

  // src/shared/sensitiveFields.ts
  function isElement2(v) {
    return !!v && typeof v === "object" && "nodeType" in v && v.nodeType === 1;
  }
  function getAttr2(el, name) {
    try {
      const v = el.getAttribute(name);
      return typeof v === "string" ? v : null;
    } catch {
      return null;
    }
  }
  function htmlElement(input) {
    if (!isElement2(input)) return null;
    if ("focus" in input && typeof input.focus === "function")
      return input;
    return null;
  }
  function detectSensitivity(input) {
    const el = htmlElement(input);
    if (!el) return "none";
    const tag2 = el.tagName.toLowerCase();
    if (tag2 === "input") {
      const type = (getAttr2(el, "type") ?? "text").toLowerCase();
      if (SENSITIVE_INPUT_TYPES.includes(type)) return "password";
    }
    const autocomplete = (getAttr2(el, "autocomplete") ?? "").toLowerCase();
    if (autocomplete) {
      const tokens = autocomplete.split(/\s+/);
      const sensitive = tokens.some((t) => SENSITIVE_AUTOCOMPLETE_TOKENS.includes(t));
      if (sensitive) {
        const hasPassword = tokens.some((t) => t.includes("password"));
        return hasPassword ? "password" : "sensitive";
      }
    }
    return "none";
  }
  function sanitizeFieldValue(input, rawValue) {
    const sens = detectSensitivity(input);
    if (sens !== "none") return null;
    if (typeof rawValue !== "string") return null;
    const v = rawValue.trim();
    if (v.length === 0) return null;
    if (v.length > 400) return `${v.slice(0, 399)}…`;
    return v;
  }
  function sanitizeVisibleText(input, rawText, sensitivity) {
    const s = sensitivity ?? detectSensitivity(input);
    if (s !== "none") return "";
    return typeof rawText === "string" ? rawText : "";
  }
  function sanitizeValue(input) {
    const el = htmlElement(input);
    if (!el) return null;
    const tag2 = el.tagName.toLowerCase();
    if (tag2 === "input" || tag2 === "textarea" || tag2 === "select") {
      const raw = el.value ?? "";
      return sanitizeFieldValue(input, raw);
    }
    return null;
  }

  // src/shared/selectorBuilder.ts
  function escapeAttr(value) {
    return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  }
  function cssSafeId(value) {
    try {
      if (typeof CSS.escape === "function") {
        return CSS.escape(value);
      }
    } catch {
    }
    return `#${value.replace(/([^a-zA-Z0-9_-])/g, "\\$1")}`;
  }
  function isPlainElement(el) {
    if (!el) return false;
    if (typeof el.nodeType !== "number") return false;
    return el.nodeType === 1;
  }
  function getAttr3(el, name) {
    try {
      if (!el || !("getAttribute" in el)) return null;
      const v = el.getAttribute(name);
      return typeof v === "string" && v.length > 0 ? v : null;
    } catch {
      return null;
    }
  }
  function hasAttr(el, name) {
    try {
      return !!el.hasAttribute?.(name);
    } catch {
      return false;
    }
  }
  function indexAmongSiblings(el, ofType = true) {
    try {
      const parent = el.parentElement;
      if (!parent) return 1;
      const siblings = ofType ? Array.from(parent.children).filter((c) => c.tagName === el.tagName) : Array.from(parent.children);
      const idx = siblings.indexOf(el);
      return idx < 0 ? 1 : idx + 1;
    } catch {
      return 1;
    }
  }
  function tag(el) {
    return el.tagName.toLowerCase();
  }
  function semanticQualifier(el) {
    const t = tag(el);
    switch (t) {
      case "button": {
        const type = getAttr3(el, "type")?.toLowerCase();
        if (type === "submit" || type === "reset" || type === "button") return `[type="${type}"]`;
        return null;
      }
      case "input":
      case "textarea":
      case "select": {
        const type = getAttr3(el, "type")?.toLowerCase();
        if (type && type.length <= 20 && /^[a-z0-9-]+$/.test(type)) return `[type="${type}"]`;
        return null;
      }
      case "label": {
        const fr = getAttr3(el, "for");
        if (fr) return `[for="${escapeAttr(fr)}"]`;
        return null;
      }
      case "a": {
        if (hasAttr(el, "href")) {
          const href = getAttr3(el, "href");
          if (href && (href.startsWith("#") || href === "")) {
            return `[href="${escapeAttr(href)}"]`;
          }
        }
        return null;
      }
      default:
        return null;
    }
  }
  function buildStructuralTail(el) {
    const parts = [];
    let cur = el;
    const maxDepth = 3;
    for (let i = 0; i < maxDepth; i += 1) {
      const idx = indexAmongSiblings(cur, true);
      const base = tag(cur);
      const qualifier = semanticQualifier(cur) ?? "";
      parts.unshift(idx > 1 ? `${base}${qualifier}:nth-of-type(${idx})` : `${base}${qualifier}`);
      const parent = cur.parentElement;
      if (!parent || parent.tagName === "BODY" || parent.tagName === "HTML") break;
      cur = parent;
    }
    return parts.join(" > ");
  }
  function buildStableSelector(input) {
    if (!isPlainElement(input)) return "";
    const el = input;
    const SEL_MAX = DEDUPLICATION.SELECTOR_MAX_LENGTH;
    const dt = getAttr3(el, "data-testid");
    if (dt) {
      const s = `[data-testid="${escapeAttr(dt)}"]`;
      if (s.length <= SEL_MAX) return s;
    }
    const dtest = getAttr3(el, "data-test");
    if (dtest) {
      const s = `[data-test="${escapeAttr(dtest)}"]`;
      if (s.length <= SEL_MAX) return s;
    }
    const aria = getAttr3(el, "aria-label");
    if (aria && aria.length >= 1 && aria.length <= 100) {
      const s = `${tag(el)}[aria-label="${escapeAttr(aria)}"]`;
      if (s.length <= SEL_MAX) return s;
    }
    const id = getAttr3(el, "id");
    if (id && /^[A-Za-z0-9_-]+$/.test(id)) {
      const s = cssSafeId(id);
      if (s.length <= SEL_MAX) return s.startsWith("#") ? s : `#${s}`;
    }
    const name = getAttr3(el, "name");
    const tg = tag(el);
    if (name && /^[A-Za-z0-9_[\].-]+$/.test(name) && ["input", "select", "textarea", "button", "form"].includes(tg)) {
      const s = `${tg}[name="${escapeAttr(name)}"]`;
      if (s.length <= SEL_MAX) return s;
    }
    const sem = semanticQualifier(el);
    if (sem) {
      const parent = el.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter(
          (c) => c.tagName === el.tagName && (getAttr3(c, "type") ?? "") === (getAttr3(el, "type") ?? "")
        );
        if (siblings.length === 1) {
          const s = `${tg}${sem}`;
          if (s.length <= SEL_MAX) return s;
        }
      }
    }
    const tail = buildStructuralTail(el);
    return tail.length > 0 ? tail : tg;
  }

  // src/shared/storageChange.ts
  function hasOwnStorageChange(changes, storageKey) {
    return Object.prototype.hasOwnProperty.call(changes, storageKey);
  }

  // src/shared/messageValidator.ts
  var STRING_TYPES = /* @__PURE__ */ new Set([
    "GET_STATE",
    "START",
    "PAUSE",
    "RESUME",
    "FINALIZE",
    "INCREMENT_STEP",
    "RESET",
    "__STATE_CHANGED__",
    "__GET_LAST_INTERACTION__",
    "__GET_LAST_STEP__",
    "__LIST_STEPS__",
    "__DELETE_STEP__",
    "__CLEAR_STEPS__",
    "__GET_PROJECT_CONTEXT__",
    "__SAVE_PROJECT_CONTEXT__",
    "__NEW_PROJECT_CONTEXT__",
    "__OPEN_PANEL_BACKGROUND__",
    "__GET_MY_TAB_ID__",
    "__RECORD_INTERACTION__",
    "__REQUEST_SCREENSHOT__",
    "__STEP_RECORDED__"
  ]);
  function isRecord(x) {
    return !!x && typeof x === "object" && !Array.isArray(x);
  }
  function isNonEmptyString(x, maxLen = 4096) {
    return typeof x === "string" && x.length >= 1 && x.length <= maxLen;
  }
  function isFiniteNumber(x, min, max) {
    if (typeof x !== "number" || !Number.isFinite(x)) return false;
    if (typeof min === "number" && x < min) return false;
    if (typeof max === "number" && x > max) return false;
    return true;
  }
  function isNullableString(x, maxLen = 400) {
    if (x === null || x === void 0) return true;
    return typeof x === "string" && x.length <= maxLen;
  }
  function isPoint(p) {
    if (!isRecord(p)) return false;
    return isFiniteNumber(p.x, -1e4, 1e5) && isFiniteNumber(p.y, -1e4, 1e5);
  }
  function isRect(r) {
    if (!isRecord(r)) return false;
    return isFiniteNumber(r.x, -1e4, 1e5) && isFiniteNumber(r.y, -1e4, 1e5) && isFiniteNumber(r.width, 0, 1e5) && isFiniteNumber(r.height, 0, 1e5);
  }
  function isTarget(t) {
    if (!isRecord(t)) return false;
    if (!isNonEmptyString(t.tagName, 100)) return false;
    if (typeof t.visibleText !== "string" || t.visibleText.length > 2e3) return false;
    if (typeof t.accessibleName !== "string" || t.accessibleName.length > 1e3) return false;
    if (!isNullableString(t.ariaLabel, 500)) return false;
    if (!isNullableString(t.title, 500)) return false;
    if (!isNullableString(t.id, 200)) return false;
    if (!isNullableString(t.name, 200)) return false;
    if (!isNullableString(t.role, 100)) return false;
    if (!isNullableString(t.fieldType, 60)) return false;
    if (!(t.value === null || typeof t.value === "string" && t.value.length <= 400)) return false;
    if (t.sensitivity !== "none" && t.sensitivity !== "password" && t.sensitivity !== "sensitive")
      return false;
    return true;
  }
  function validateRuntimeMessage(msg) {
    if (!isRecord(msg)) return { ok: false, error: "mensagem nao e objeto" };
    const type = msg.type;
    if (!isNonEmptyString(type, 100) || !STRING_TYPES.has(type)) {
      return { ok: false, error: `tipo de mensagem invalido: ${String(type).slice(0, 80)}` };
    }
    if (msg.payload !== void 0 && msg.payload !== null && !isRecord(msg.payload)) {
      return { ok: false, error: "payload deve ser objeto ou undefined" };
    }
    return { ok: true, value: msg };
  }
  function validateInteractionEvent(ev) {
    if (!isRecord(ev)) return { ok: false, error: "interacao nao e objeto" };
    if (!isNonEmptyString(ev.interactionId, 128))
      return { ok: false, error: "interactionId invalido" };
    if (!(ev.sessionId === null || isNonEmptyString(ev.sessionId, 200)))
      return { ok: false, error: "sessionId invalido" };
    if (!isTarget(ev.target)) return { ok: false, error: "target invalido" };
    if (!isPoint(ev.viewportPoint)) return { ok: false, error: "viewportPoint invalido" };
    if (!isRect(ev.elementRect)) return { ok: false, error: "elementRect invalido" };
    if (!isNonEmptyString(ev.url, 4096)) return { ok: false, error: "url invalida" };
    if (typeof ev.pageTitle !== "string" || ev.pageTitle.length > 2e3)
      return { ok: false, error: "pageTitle invalido" };
    if (!isRecord(ev.viewportSize) || !isFiniteNumber(ev.viewportSize.width, 0, 1e5) || !isFiniteNumber(ev.viewportSize.height, 0, 1e5)) {
      return { ok: false, error: "viewportSize invalido" };
    }
    if (!isFiniteNumber(ev.devicePixelRatio, 0.1, 10))
      return { ok: false, error: "devicePixelRatio invalido" };
    if (!isFiniteNumber(ev.timestamp)) return { ok: false, error: "timestamp invalido" };
    if (typeof ev.stableSelector !== "string" || ev.stableSelector.length > 1024)
      return { ok: false, error: "stableSelector invalido" };
    if (!["mouse", "touch", "pen", "unknown"].includes(String(ev.inputSource))) {
      return { ok: false, error: "inputSource invalido" };
    }
    if (typeof ev.isTrusted !== "boolean") return { ok: false, error: "isTrusted invalido" };
    return { ok: true, value: ev };
  }

  // src/shared/uuid.ts
  function uuidv4() {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      try {
        return crypto.randomUUID();
      } catch {
      }
    }
    const bytes = Array.from(
      typeof crypto !== "undefined" && typeof crypto.getRandomValues === "function" ? crypto.getRandomValues(new Uint8Array(16)) : Array.from({ length: 16 }, () => Math.floor(Math.random() * 256))
    );
    bytes[6] = bytes[6] & 15 | 64;
    bytes[8] = bytes[8] & 63 | 128;
    const hex = bytes.map((b) => b.toString(16).padStart(2, "0")).join("");
    return [
      hex.slice(0, 8),
      hex.slice(8, 12),
      hex.slice(12, 16),
      hex.slice(16, 20),
      hex.slice(20, 32)
    ].join("-");
  }

  // src/content/index.ts
  var BANNER_ID = "__homolog_restricted_banner__";
  var MARKER_ID = SCREENSHOT.POINTER_MARKER_ID;
  var CONTROLS_ID = "__homolog_recording_controls__";
  var CONTENT_INSTANCE_ATTRIBUTE = "data-homolog-recorder-active";
  var CONTENT_INSTANCE_GLOBAL = "__homologRecorderContentInitialized__";
  var OWN_ELEMENT_MARKERS = [BANNER_ID, MARKER_ID, CONTROLS_ID];
  var FINALIZATION_DELAY_MS = 0;
  var REQUEST_TIMEOUT_MS = SCREENSHOT.TIMEOUT_MS;
  var pending = /* @__PURE__ */ new Map();
  var logger = {
    info: (...args) => console.log("[homolog:cs]", ...args),
    warn: (...args) => console.warn("[homolog:cs]", ...args),
    error: (...args) => console.error("[homolog:cs]", ...args)
  };
  var state = {
    recording: false,
    sessionId: null,
    ownTabId: null,
    restricted: false,
    listenerAttached: false,
    markerTimeoutIds: [],
    session: null,
    controlSteps: [],
    controlsExpanded: false,
    projectContext: { name: "Projeto padrão", functionality: "", locked: false },
    pendingPanelOpen: false
  };
  function setControlsCaptureHidden(hidden) {
    const host = document.getElementById(CONTROLS_ID);
    if (host) host.style.visibility = hidden ? "hidden" : "visible";
  }
  async function controlAction(type) {
    const response = await sendMessage({ type });
    if (!response.ok) logger.warn("controle flutuante rejeitado", response.error);
    if (response.state) {
      applySessionState(response.state);
      if (response.ok && type === "START") {
        state.controlsExpanded = false;
        renderRecordingControls(response.state);
      }
      if (response.ok && type === "RESUME") {
        state.controlsExpanded = false;
        renderRecordingControls(response.state);
      }
    }
  }
  async function toggleRecordingControls() {
    state.controlsExpanded = !state.controlsExpanded;
    renderRecordingControls(state.session);
  }
  function renderStepPreviews() {
    const root = document.getElementById(CONTROLS_ID)?.shadowRoot;
    const list = root?.querySelector(".step-list");
    const empty = root?.querySelector(".step-empty");
    if (!list || !empty) return;
    list.replaceChildren();
    const recent = state.controlSteps.slice(-12).sort((a, b) => a.sequence - b.sequence);
    empty.hidden = recent.length > 0;
    for (const step of recent) {
      const item = document.createElement("li");
      item.className = "step-item";
      item.tabIndex = 0;
      item.setAttribute("role", "button");
      item.setAttribute("aria-label", `Visualizar passo ${step.sequence} em tela cheia`);
      const thumb = document.createElement("div");
      thumb.className = "thumb";
      if (step.screenshotDataUrl) {
        const image = document.createElement("img");
        image.src = step.screenshotDataUrl;
        image.alt = "";
        thumb.appendChild(image);
      }
      const detail = document.createElement("div");
      detail.className = "step-detail";
      const title = document.createElement("strong");
      title.textContent = `Passo ${step.sequence}`;
      const description = document.createElement("span");
      description.textContent = step.description || "Clique registrado";
      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.className = "step-delete";
      deleteButton.textContent = "🗑 Excluir";
      deleteButton.setAttribute("aria-label", `Excluir passo ${step.sequence}`);
      deleteButton.addEventListener("click", (event) => {
        event.stopPropagation();
        void deleteControlStep(step.stepId);
      });
      detail.append(title, description, deleteButton);
      item.append(thumb, detail);
      const openViewer = () => {
        if (!step.screenshotDataUrl) return;
        const viewer = root?.querySelector(".viewer");
        const viewerImage = root?.querySelector(".viewer img");
        const viewerTitle = root?.querySelector(".viewer-title");
        if (viewer && viewerImage && viewerTitle) {
          viewerImage.src = step.screenshotDataUrl;
          viewerImage.alt = `Screenshot do passo ${step.sequence}`;
          viewerTitle.textContent = `Passo ${step.sequence} — ${step.description || "Clique registrado"}`;
          viewer.hidden = false;
          root?.querySelector(".viewer-close")?.focus();
        }
      };
      item.addEventListener("click", openViewer);
      item.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          openViewer();
        }
      });
      list.appendChild(item);
    }
  }
  async function refreshControlSteps() {
    const response = await sendMessage({ type: "__LIST_STEPS__" });
    if (!response.ok || !response.steps) return;
    state.controlSteps = response.steps;
    renderRecordingControls(state.session);
  }
  async function deleteControlStep(stepId) {
    const response = await sendMessage({ type: "__DELETE_STEP__", payload: { stepId } });
    if (!response.ok) {
      logger.warn("não foi possível excluir o passo", response.error);
      return;
    }
    state.controlSteps = response.steps ?? state.controlSteps.filter((step) => step.stepId !== stepId);
    if (response.state) applySessionState(response.state);
    renderRecordingControls(state.session);
  }
  async function clearControlSteps() {
    if (!window.confirm("Excluir todos os passos desta sessão?")) return;
    const response = await sendMessage({ type: "__CLEAR_STEPS__" });
    if (!response.ok) {
      logger.warn("não foi possível limpar os passos", response.error);
      return;
    }
    state.controlSteps = [];
    if (response.state) applySessionState(response.state);
    renderRecordingControls(state.session);
  }
  async function loadProjectContext() {
    const response = await sendMessage({ type: "__GET_PROJECT_CONTEXT__" });
    if (response.ok && response.projectContext) {
      state.projectContext = response.projectContext;
      renderRecordingControls(state.session);
    }
  }
  async function saveProjectContext() {
    const root = document.getElementById(CONTROLS_ID)?.shadowRoot;
    const name = root?.querySelector(".project-name")?.value ?? "";
    const functionality = root?.querySelector(".project-functionality")?.value ?? "";
    const response = await sendMessage({
      type: "__SAVE_PROJECT_CONTEXT__",
      payload: { name, functionality }
    });
    if (!response.ok) {
      logger.warn("não foi possível salvar os dados do projeto", response.error);
      return;
    }
    if (response.projectContext) state.projectContext = response.projectContext;
    renderRecordingControls(state.session);
  }
  function openHomologPanel() {
    const url = new URL("http://localhost:5173/");
    url.searchParams.set("homologExtensionId", chrome.runtime.id);
    window.open(url.toString(), "_blank", "noopener");
  }
  function requestPanelOpen() {
    const current = state.session?.state;
    if (current === "recording" || current === "paused") {
      state.pendingPanelOpen = true;
      showPanelRecordingAlert();
      return;
    }
    openHomologPanel();
  }
  function showPanelRecordingAlert() {
    const root = document.getElementById(CONTROLS_ID)?.shadowRoot;
    if (!root || root.querySelector(".panel-recording-alert")) return;
    const dialog = document.createElement("div");
    dialog.className = "panel-recording-alert";
    dialog.setAttribute("role", "alertdialog");
    dialog.setAttribute("aria-modal", "true");
    dialog.style.cssText = "position:fixed;inset:0;z-index:2147483647;display:grid;place-items:center;padding:22px;background:rgba(10,15,23,.82);pointer-events:auto";
    dialog.innerHTML = '<div style="box-sizing:border-box;width:min(402px,calc(100vw - 44px));padding:23px 19px 19px;border:1px solid #315f91;border-radius:12px;background:#0d213a;color:#fff;box-shadow:0 18px 48px rgba(0,0,0,.48)"><p style="margin:0 0 18px;font:700 13px/1.65 system-ui,-apple-system,Segoe UI,sans-serif">Finalize a gravação atual para acessar o painel</p><button class="alert-ok" type="button" style="display:block;width:100%;min-height:38px;border:0;border-radius:9px;background:#188a57;color:#fff;font:700 12px system-ui">Entendi</button></div>';
    dialog.querySelector(".alert-ok")?.addEventListener("click", () => dialog.remove());
    root.appendChild(dialog);
    dialog.querySelector(".alert-ok")?.focus();
  }
  function confirmNewProject() {
    return new Promise((resolve) => {
      const root = document.getElementById(CONTROLS_ID)?.shadowRoot;
      if (!root) return resolve(false);
      root.querySelector(".new-project-confirm")?.remove();
      const dialog = document.createElement("div");
      dialog.className = "new-project-confirm";
      dialog.setAttribute("role", "alertdialog");
      dialog.setAttribute("aria-modal", "true");
      dialog.style.cssText = "position:fixed;inset:0;z-index:2147483647;display:grid;place-items:center;padding:22px;background:rgba(10,15,23,.82);pointer-events:auto";
      dialog.innerHTML = '<div style="box-sizing:border-box;width:min(402px,calc(100vw - 44px));padding:23px 19px 19px;border:1px solid #315f91;border-radius:12px;background:#0d213a;color:#fff;box-shadow:0 18px 48px rgba(0,0,0,.48)"><p style="margin:0 0 18px;font:700 13px/1.65 system-ui,-apple-system,Segoe UI,sans-serif">Seus passos atuais serão enviados ao painel, deseja continuar?</p><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px"><button class="confirm-no" type="button" style="min-height:38px;border:2px solid #dce7f5;border-radius:9px;background:#52637a;color:#fff;font-weight:700">Não</button><button class="confirm-yes" type="button" style="min-height:38px;border:0;border-radius:9px;background:#188a57;color:#fff;font-weight:700">Sim</button></div></div>';
      const finish = (answer) => {
        dialog.remove();
        resolve(answer);
      };
      dialog.querySelector(".confirm-no")?.addEventListener("click", () => finish(false));
      dialog.querySelector(".confirm-yes")?.addEventListener("click", () => finish(true));
      root.appendChild(dialog);
      dialog.querySelector(".confirm-no")?.focus();
    });
  }
  async function createNewProjectContext() {
    if (!await confirmNewProject()) return;
    const response = await sendMessage({ type: "__NEW_PROJECT_CONTEXT__" });
    if (!response.ok) {
      logger.warn("não foi possível criar o novo projeto", response.error);
      return;
    }
    state.controlSteps = [];
    if (response.projectContext) state.projectContext = response.projectContext;
    if (response.state) applySessionState(response.state);
    state.controlsExpanded = true;
    renderRecordingControls(state.session);
    document.getElementById(CONTROLS_ID)?.shadowRoot?.querySelector(".project-name")?.focus();
  }
  function renderRecordingControls(session) {
    if (typeof document === "undefined" || state.restricted) return;
    let host = document.getElementById(CONTROLS_ID);
    if (!host) {
      host = document.createElement("div");
      host.id = CONTROLS_ID;
      host.style.cssText = "all:initial;position:fixed;inset:0 0 0 auto;z-index:2147483646;pointer-events:none";
      const shadow = host.attachShadow({ mode: "open" });
      shadow.innerHTML = `<style>
      :host{all:initial}.drawer{position:absolute;top:0;right:0;width:330px;height:100vh;padding:18px 14px 14px;box-sizing:border-box;border-left:1px solid #29476f;background:#0b1729f7;color:#eaf2ff;box-shadow:-16px 0 40px #0006;font:13px/1.35 system-ui,-apple-system,Segoe UI,sans-serif;pointer-events:auto;transform:translateX(0);transition:transform .22s ease;display:flex;flex-direction:column}.drawer.closed{transform:translateX(100%)}.toggle{position:absolute;top:50%;left:-38px;width:38px;height:64px;transform:translateY(-50%);border:1px solid #29476f;border-right:0;border-radius:12px 0 0 12px;background:#0b1729f7;color:#fff;font-size:24px;cursor:pointer;box-shadow:-7px 4px 18px #0004}.head{display:flex;align-items:center;justify-content:space-between;gap:8px}.brand{font-size:15px;font-weight:750}.state{font-size:11px;color:#9fc2ff}.count{min-width:25px;padding:3px 7px;border-radius:20px;background:#17345b;text-align:center;font-weight:700}.actions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:14px}button{border:0;border-radius:9px;padding:9px;background:#1b365c;color:#fff;font:600 12px system-ui;cursor:pointer}button:hover{filter:brightness(1.13)}button[data-action="START"]{background:#15804f}button[data-action="PAUSE"]{background:#a56108}button[data-action="RESUME"]{background:#2867d8}button[data-action="FINALIZE"]{background:#a83242}.clear-steps{grid-column:1/-1;background:#7f1d1d}.step-delete{margin-top:auto;padding:4px 7px;align-self:flex-end;background:#7f1d1d;font-size:11px}button:disabled{opacity:.38;filter:saturate(.3);cursor:default}.preview-head{display:flex;align-items:center;justify-content:space-between;margin:18px 0 8px;padding-top:14px;border-top:1px solid #29476f}.preview-head strong{font-size:12px}.step-scroll{min-height:0;overflow:auto;flex:1;padding-right:3px}.step-list{display:grid;gap:8px;padding:0;margin:0;list-style:none}.step-item{display:grid;grid-template-columns:92px 1fr;gap:9px;padding:7px;border:1px solid #29476f;border-radius:10px;background:#101f35;cursor:pointer}.step-item:hover,.step-item:focus-visible{border-color:#6fa2ed;background:#142946;outline:none}.thumb{width:92px;aspect-ratio:16/9;border-radius:6px;background:#1b365c;overflow:hidden}.thumb img{width:100%;height:100%;object-fit:cover}.step-detail{min-width:0;display:flex;flex-direction:column;gap:4px}.step-detail strong{font-size:11px;color:#9fc2ff}.step-detail span{display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:3;font-size:11px}.step-empty{padding:22px 8px;text-align:center;color:#9fb0ca}.foot{display:flex;justify-content:flex-end;padding-top:10px}.panel{padding:5px;background:transparent;color:#9fc2ff}.viewer{position:fixed;inset:0;z-index:2147483647;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:32px;background:#02060ded;color:#fff;pointer-events:auto;font:13px/1.4 system-ui,-apple-system,Segoe UI,sans-serif}.viewer[hidden]{display:none}.viewer img{display:block;max-width:calc(100vw - 64px);max-height:calc(100vh - 110px);object-fit:contain;border-radius:8px;box-shadow:0 18px 60px #000}.viewer-title{max-width:900px;text-align:center}.viewer-close{position:absolute;top:18px;right:20px;width:42px;height:42px;border-radius:50%;font-size:24px;background:#172a48}@media(max-width:520px){.drawer{width:min(88vw,330px)}.viewer{padding:18px}.viewer img{max-width:calc(100vw - 36px)}}
    </style><aside class="drawer" aria-label="Menu Homolog"><button class="toggle" aria-label="Fechar menu Homolog" title="Abrir ou fechar menu">›</button><div class="head"><span class="brand">🎬 Homolog</span><span class="state"></span><span class="count">0</span></div><div class="actions"><button data-action="START">Iniciar gravação</button><button data-action="PAUSE">Pausar</button><button data-action="RESUME">Continuar</button><button data-action="FINALIZE">Finalizar</button><button class="clear-steps">Limpar passos</button></div><div class="preview-head"><strong>Pré-visualização dos passos</strong><span class="preview-count">0</span></div><div class="step-scroll"><div class="step-empty">Nenhum passo registrado.</div><ol class="step-list"></ol></div><div class="foot"><button class="panel">Abrir painel ↗</button></div></aside><div class="viewer" role="dialog" aria-modal="true" aria-label="Visualização do passo" hidden><button class="viewer-close" aria-label="Fechar visualização">×</button><img alt=""><div class="viewer-title"></div></div>`;
      const projectContext = document.createElement("div");
      projectContext.className = "project-context";
      projectContext.style.cssText = "display:grid;gap:7px;margin-top:14px;padding:11px;border:1px solid #29476f;border-radius:10px;background:#101f35";
      projectContext.innerHTML = '<label style="display:grid;gap:3px;color:#9fc2ff;font-size:11px">Nome do projeto<input class="project-name" maxlength="200" style="padding:7px;border:1px solid #365577;border-radius:7px;background:#091426;color:#fff"></label><label style="display:grid;gap:3px;color:#9fc2ff;font-size:11px">Funcionalidade<input class="project-functionality" maxlength="300" style="padding:7px;border:1px solid #365577;border-radius:7px;background:#091426;color:#fff"></label><button class="save-project" type="button" style="background:#2867d8">Salvar dados</button><button class="new-project" type="button" style="background:#15804f" hidden>Novo projeto / funcionalidade</button>';
      shadow.querySelector(".actions")?.before(projectContext);
      const head = shadow.querySelector(".head");
      if (head) head.style.cssText = "position:relative;display:flex;align-items:center;justify-content:center;min-height:24px";
      const brand = shadow.querySelector(".brand");
      if (brand) brand.textContent = "📷 Homolog";
      const stateLabel = shadow.querySelector(".state");
      if (stateLabel) stateLabel.style.cssText = "position:absolute;left:0;font-size:11px;color:#9fc2ff";
      shadow.querySelector(".count")?.remove();
      const panelButton = shadow.querySelector(".panel");
      if (panelButton && head) {
        panelButton.style.cssText = "width:100%;margin-top:10px;padding:8px;background:#152a47;color:#9fc2ff";
        head.after(panelButton);
      }
      shadow.querySelector(".save-project")?.addEventListener("click", () => void saveProjectContext());
      shadow.querySelector(".new-project")?.addEventListener("click", () => void createNewProjectContext());
      shadow.querySelectorAll("[data-action]").forEach((button) => button.addEventListener("click", () => void controlAction(button.dataset.action)));
      shadow.querySelector(".panel")?.addEventListener("click", requestPanelOpen);
      shadow.querySelector(".toggle")?.addEventListener("click", () => void toggleRecordingControls());
      shadow.querySelector(".clear-steps")?.addEventListener("click", () => void clearControlSteps());
      const closeViewer = () => {
        const viewer = shadow.querySelector(".viewer");
        if (viewer) viewer.hidden = true;
      };
      shadow.querySelector(".viewer-close")?.addEventListener("click", closeViewer);
      shadow.querySelector(".viewer")?.addEventListener("click", (event) => {
        if (event.target === event.currentTarget) closeViewer();
      });
      shadow.addEventListener("keydown", (event) => {
        if (event.key === "Escape") closeViewer();
      });
      (document.documentElement || document.body).appendChild(host);
    }
    const belongsToThisTab = !session || session.state === "idle" || session.state === "finalized" || state.ownTabId === null || session.tabId === state.ownTabId;
    host.style.display = belongsToThisTab ? "block" : "none";
    const root = host.shadowRoot;
    const drawer = root?.querySelector(".drawer");
    drawer?.classList.toggle("closed", !state.controlsExpanded);
    const toggle = root?.querySelector(".toggle");
    if (toggle) {
      toggle.textContent = state.controlsExpanded ? "›" : "‹";
      toggle.setAttribute("aria-label", state.controlsExpanded ? "Fechar menu Homolog" : "Abrir menu Homolog");
    }
    const current = session?.state ?? "idle";
    const labels = { idle: "Pronto", recording: "Gravando", paused: "Pausado", finalized: "Finalizado" };
    const stateEl = root?.querySelector(".state");
    if (stateEl) stateEl.textContent = labels[current];
    const previewCount = root?.querySelector(".preview-count");
    if (previewCount) previewCount.textContent = `${state.controlSteps.length} passos`;
    const projectName = root?.querySelector(".project-name");
    if (projectName && root?.activeElement !== projectName) projectName.value = state.projectContext.name;
    const functionality = root?.querySelector(".project-functionality");
    if (functionality && root?.activeElement !== functionality) functionality.value = state.projectContext.functionality;
    if (projectName) projectName.readOnly = state.projectContext.locked === true;
    if (functionality) functionality.readOnly = state.projectContext.locked === true;
    const saveProject = root?.querySelector(".save-project");
    if (saveProject) saveProject.hidden = state.projectContext.locked === true;
    const newProject = root?.querySelector(".new-project");
    if (newProject) newProject.hidden = state.projectContext.locked !== true;
    root?.querySelectorAll("[data-action]").forEach((button) => {
      const action = button.dataset.action;
      button.hidden = action === "START" && (current === "recording" || current === "paused");
      button.disabled = action === "START" ? current === "recording" || current === "paused" : action === "PAUSE" ? current !== "recording" : action === "RESUME" ? current !== "paused" : current !== "recording" && current !== "paused";
    });
    renderStepPreviews();
  }
  function getRestrictionInfo() {
    try {
      const location = typeof window !== "undefined" ? window.location?.href : "";
      const info = isRestrictedUrl(location);
      return info.restricted ? info : null;
    } catch {
      return null;
    }
  }
  function makeBannerText(info) {
    const base = RESTRICTED_PAGE_REASONS[info.reason ?? "internal"];
    return base ?? "O Homolog Recorder não funciona nesta página por restrições do navegador.";
  }
  function renderBanner(info) {
    if (typeof document === "undefined") return;
    if (document.getElementById(BANNER_ID)) return;
    const banner = document.createElement("div");
    banner.id = BANNER_ID;
    banner.setAttribute("role", "status");
    const cssText = [
      "all: initial",
      "position: fixed",
      "top: 8px",
      "left: 50%",
      "transform: translateX(-50%)",
      "z-index: 2147483647",
      "max-width: 640px",
      "width: calc(100% - 32px)",
      "padding: 10px 14px",
      "border-radius: 10px",
      "background: rgba(239,68,68,0.92)",
      "color: #fff",
      "font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, sans-serif",
      "font-size: 13px",
      "line-height: 1.4",
      "box-shadow: 0 10px 25px rgba(0,0,0,0.2)",
      "backdrop-filter: blur(4px)",
      "display: flex",
      "gap: 10px",
      "align-items: flex-start",
      "border: 1px solid rgba(255,255,255,0.15)"
    ].join(";");
    banner.style.cssText = cssText;
    banner.innerHTML = [
      `<span aria-hidden="true" style="flex-shrink:0; font-weight:700;">⚠️</span>`,
      `<div>`,
      `<strong style="display:block; margin-bottom:2px;">Homolog Recorder indisponível aqui</strong>`,
      `<span style="opacity:0.95;">${makeBannerText(info)}</span>`,
      `</div>`,
      `<button type="button" aria-label="Fechar aviso" style="`,
      ` all: initial;`,
      ` flex-shrink:0;`,
      ` cursor:pointer;`,
      ` color: #fff;`,
      ` opacity:0.85;`,
      ` font-size:14px;`,
      ` padding: 0 6px;`,
      `">&times;</button>`
    ].join("");
    const closeBtn = banner.querySelector("button");
    closeBtn?.addEventListener("click", () => {
      banner.style.transition = "opacity 200ms ease";
      banner.style.opacity = "0";
      setTimeout(() => banner.remove(), 220);
    });
    try {
      document.documentElement.appendChild(banner);
    } catch {
      try {
        document.body.appendChild(banner);
      } catch {
      }
    }
  }
  function insertClickMarker(x, y) {
    try {
      if (typeof document === "undefined") return null;
      let marker = document.getElementById(MARKER_ID);
      if (!marker) {
        marker = document.createElement("div");
        marker.id = MARKER_ID;
        marker.setAttribute("data-homolog", "marker");
        marker.setAttribute("aria-hidden", "true");
        const radius = SCREENSHOT.POINTER_MARKER_RADIUS_PX;
        const outer = radius * 2;
        marker.style.cssText = [
          "all: initial",
          "position: fixed",
          `left: ${x - radius}px`,
          `top: ${y - radius}px`,
          `width: ${outer}px`,
          `height: ${outer}px`,
          "border-radius: 999px",
          "border: 2px solid #dc2626",
          "box-shadow: 0 0 0 3px rgba(220, 38, 38, 0.22), 0 4px 14px rgba(0,0,0,0.25)",
          "pointer-events: none",
          "z-index: 2147483646",
          "mix-blend-mode: normal",
          "will-change: left, top, opacity",
          "contain: layout style paint"
        ].join(";");
        try {
          document.documentElement.appendChild(marker);
        } catch {
          try {
            document.body.appendChild(marker);
          } catch {
            return null;
          }
        }
      } else {
        const radius = SCREENSHOT.POINTER_MARKER_RADIUS_PX;
        marker.style.left = `${x - radius}px`;
        marker.style.top = `${y - radius}px`;
        marker.style.opacity = "1";
        marker.style.display = "block";
      }
      return MARKER_ID;
    } catch {
      return null;
    }
  }
  function removeClickMarker() {
    try {
      if (typeof document === "undefined") return;
      const el = document.getElementById(MARKER_ID);
      if (!el) return;
      el.style.opacity = "0";
      const toId = window.setTimeout(() => {
        try {
          el.remove();
        } catch {
        }
      }, 120);
      state.markerTimeoutIds.push(Number(toId));
      if (state.markerTimeoutIds.length > 12) {
        const old = state.markerTimeoutIds.shift();
        if (old) clearTimeout(old);
      }
    } catch {
    }
  }
  function clearAllMarkerTimeouts() {
    while (state.markerTimeoutIds.length) {
      const id = state.markerTimeoutIds.shift();
      if (id) clearTimeout(id);
    }
    removeClickMarker();
  }
  function isOwnElement(target) {
    if (!target) return false;
    try {
      let node = target;
      for (let i = 0; i < 20 && node; i += 1) {
        if (node.nodeType === 1) {
          const el = node;
          const id = el.id;
          if (id && OWN_ELEMENT_MARKERS.includes(id)) return true;
        }
        node = node.parentNode ?? null;
      }
    } catch {
    }
    return false;
  }
  function safeGetAttr(el, name) {
    try {
      const v = el.getAttribute(name);
      return typeof v === "string" && v.length > 0 ? v : null;
    } catch {
      return null;
    }
  }
  function extractTarget(target) {
    if (!target) return null;
    const el = target.nodeType === 1 ? target : null;
    if (!el) return null;
    try {
      void el.tagName;
    } catch {
      return null;
    }
    if (!document.documentElement.contains(el)) {
      return null;
    }
    const sensitivity = detectSensitivity(el);
    const tag2 = (el.tagName || "").toLowerCase() || "element";
    const value = sanitizeValue(el);
    const visibleRaw = extractVisibleText(el, sensitivity !== "none");
    const visibleText = sanitizeVisibleText(el, visibleRaw, sensitivity);
    const accessibleName = sanitizeVisibleText(el, computeAccessibleName(el), sensitivity);
    return {
      tagName: tag2,
      visibleText,
      accessibleName,
      ariaLabel: safeGetAttr(el, "aria-label"),
      title: safeGetAttr(el, "title"),
      id: safeGetAttr(el, "id"),
      name: safeGetAttr(el, "name"),
      role: safeGetAttr(el, "role"),
      fieldType: tag2 === "input" || tag2 === "button" || tag2 === "select" ? safeGetAttr(el, "type") : null,
      value,
      sensitivity
    };
  }
  function resolveInputSource(ev) {
    const t = (ev?.pointerType ?? "").toLowerCase();
    if (t === "mouse" || t === "touch" || t === "pen") return t;
    return "unknown";
  }
  function sendMessage(msg, timeoutMs = REQUEST_TIMEOUT_MS) {
    return new Promise((resolve) => {
      let settled = false;
      const timer = window.setTimeout(
        () => {
          if (settled) return;
          settled = true;
          resolve({ ok: false, error: `timeout apos ${timeoutMs}ms` });
        },
        Math.max(500, timeoutMs)
      );
      const finish = (r) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(r);
      };
      try {
        chrome.runtime.sendMessage(msg, (resp) => {
          const err = chrome.runtime?.lastError;
          if (err && !resp) {
            finish({ ok: false, error: err.message ?? "runtime error" });
            return;
          }
          if (typeof resp === "object" && resp !== null && "ok" in resp) {
            finish(resp);
            return;
          }
          finish({ ok: false, error: "resposta invalida do bg" });
        });
      } catch (e) {
        finish({
          ok: false,
          error: e instanceof Error ? e.message : String(e)
        });
      }
    });
  }
  async function finalizeInteraction(id, interaction) {
    if (!pending.has(id)) return;
    pending.delete(id);
    const msgValid = validateRuntimeMessage({
      type: "__RECORD_INTERACTION__",
      payload: { interaction }
    });
    if (!msgValid.ok) {
      logger.warn("mensagem invalida antes do envio", msgValid.error);
      return;
    }
    const evValid = validateInteractionEvent(interaction);
    if (!evValid.ok) {
      logger.warn("interacao invalida antes do envio", evValid.error);
      return;
    }
    let markerRemoved = false;
    const removeMarkerSafe = () => {
      if (markerRemoved) return;
      markerRemoved = true;
      removeClickMarker();
    };
    try {
      insertClickMarker(interaction.viewportPoint.x, interaction.viewportPoint.y);
      setControlsCaptureHidden(true);
      const requestMsg = validateRuntimeMessage({
        type: "__REQUEST_SCREENSHOT__",
        payload: { interaction }
      });
      if (!requestMsg.ok) {
        logger.warn("request msg invalida", requestMsg.error);
        return;
      }
      const resp = await sendMessage(requestMsg.value);
      if (!resp.ok) {
        logger.warn("bg rejeitou screenshot / step", resp.error);
        return;
      }
    } catch (e) {
      logger.warn("erro ao enviar request screenshot", e);
    } finally {
      setControlsCaptureHidden(false);
      removeMarkerSafe();
    }
  }
  function scheduleInteractionFinalization(id, interaction, delayMs = FINALIZATION_DELAY_MS) {
    if (pending.has(id)) return;
    pending.set(id, { createdAt: Date.now(), timeoutId: null });
    if (delayMs <= 0) {
      void finalizeInteraction(id, interaction);
      return;
    }
    const timeoutId = setTimeout(() => void finalizeInteraction(id, interaction), delayMs);
    pending.set(id, { createdAt: Date.now(), timeoutId });
  }
  function cancelPendingInteractions() {
    for (const [, v] of pending) {
      if (v.timeoutId !== null) clearTimeout(v.timeoutId);
    }
    pending.clear();
    clearAllMarkerTimeouts();
  }
  function onPageHideSoon() {
    clearAllMarkerTimeouts();
  }
  function onPointerDownCapture(evt) {
    try {
      if (!state.recording) return;
      if (state.restricted) return;
      const pe = evt;
      if (!pe.isTrusted) return;
      if (isOwnElement(evt.target)) return;
      const composedTarget = pe.composedPath?.()?.[0] ?? evt.target;
      const targetInfo = extractTarget(composedTarget);
      if (!targetInfo) return;
      const viewportPoint = {
        x: Number.isFinite(pe.clientX) ? pe.clientX : 0,
        y: Number.isFinite(pe.clientY) ? pe.clientY : 0
      };
      const el = composedTarget?.nodeType === 1 ? composedTarget : null;
      let rect = {
        x: viewportPoint.x,
        y: viewportPoint.y,
        width: 0,
        height: 0
      };
      if (el && typeof el.getBoundingClientRect === "function") {
        try {
          const r = el.getBoundingClientRect();
          rect = { x: r.x, y: r.y, width: Math.max(0, r.width), height: Math.max(0, r.height) };
        } catch {
        }
      }
      const stableSelector = buildStableSelector(el);
      const interaction = {
        interactionId: uuidv4(),
        sessionId: state.sessionId,
        target: targetInfo,
        viewportPoint,
        elementRect: rect,
        url: window.location?.href ?? "",
        pageTitle: document?.title ?? "",
        viewportSize: {
          width: window?.innerWidth ?? 0,
          height: window?.innerHeight ?? 0
        },
        devicePixelRatio: window?.devicePixelRatio ?? 1,
        timestamp: Date.now(),
        stableSelector,
        inputSource: resolveInputSource(pe),
        isTrusted: true
      };
      scheduleInteractionFinalization(interaction.interactionId, interaction);
    } catch (e) {
      logger.warn("onPointerDown capture handler falhou", e);
    }
  }
  function attachListener() {
    if (state.listenerAttached) return;
    if (typeof document === "undefined" || !document.addEventListener) return;
    document.addEventListener("pointerdown", onPointerDownCapture, true);
    state.listenerAttached = true;
    logger.info("pointerdown listener anexado (capture)");
  }
  function detachListener() {
    if (!state.listenerAttached) return;
    if (typeof document === "undefined") return;
    document.removeEventListener("pointerdown", onPointerDownCapture, true);
    state.listenerAttached = false;
    cancelPendingInteractions();
    logger.info("pointerdown listener removido");
  }
  function applySessionState(s) {
    const wasRecording = state.recording;
    const previousSessionState = state.session?.state;
    const baseRecording = s?.state === "recording";
    state.sessionId = s?.sessionId ?? null;
    state.session = s;
    if (baseRecording && s?.tabId !== null && s?.tabId !== void 0 && state.ownTabId !== null) {
      if (s.tabId !== state.ownTabId) {
        logger.info(
          `esta aba #${state.ownTabId} nao e a aba gravada #${s.tabId}; desativando recording aqui`
        );
        state.recording = false;
      } else {
        state.recording = !state.restricted;
      }
    } else if (baseRecording && state.ownTabId === null) {
      logger.info(
        "ownTabId ainda desconhecido; permitindo recording temporariamente (SW filtrara sender.tab.id)"
      );
      state.recording = !state.restricted;
    } else {
      state.recording = baseRecording && !state.restricted;
    }
    if (!wasRecording && state.recording) {
      attachListener();
    } else if (wasRecording && !state.recording) {
      detachListener();
    } else if (state.recording && !state.listenerAttached) {
      attachListener();
    }
    logger.info(
      "state aplicado recording=",
      state.recording,
      "sessionId=",
      state.sessionId?.slice(0, 8),
      "ownTabId=",
      state.ownTabId,
      "session.tabId=",
      s?.tabId
    );
    if (!state.recording) {
      clearAllMarkerTimeouts();
    }
    renderRecordingControls(s);
    if ((s?.stepCount ?? 0) !== state.controlSteps.length) void refreshControlSteps();
    if (state.pendingPanelOpen && (previousSessionState === "recording" || previousSessionState === "paused") && s?.state === "finalized") {
      state.pendingPanelOpen = false;
    }
  }
  async function resolveOwnTabId() {
    try {
      const msgValid = validateRuntimeMessage({
        type: "__GET_MY_TAB_ID__"
      });
      if (!msgValid.ok) return;
      const resp = await sendMessage(msgValid.value, CHROME_MESSAGE_TIMEOUT_MS);
      if (resp.ok && typeof resp.tabId === "number") {
        state.ownTabId = resp.tabId;
        logger.info("content ownTabId resolvido para", state.ownTabId);
      }
    } catch (e) {
      logger.warn("resolveOwnTabId falhou", e);
    }
  }
  async function fetchInitialState() {
    try {
      const msgValid = validateRuntimeMessage({ type: "GET_STATE" });
      if (!msgValid.ok) return;
      const resp = await sendMessage(msgValid.value);
      if (resp.ok && resp.state) applySessionState(resp.state);
    } catch (e) {
      logger.warn("fetchInitialState falhou", e);
    }
  }
  function initStorageListener() {
    try {
      chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName !== "local") return;
        if (!hasOwnStorageChange(changes, STORAGE_KEY_RECORDING)) return;
        const raw = changes[STORAGE_KEY_RECORDING]?.newValue;
        if (raw && typeof raw === "object") {
          applySessionState(raw);
        } else {
          applySessionState(null);
        }
      });
    } catch (e) {
      logger.warn("initStorageListener falhou", e);
    }
  }
  function initRuntimeListener() {
    try {
      chrome.runtime.onMessage.addListener((raw) => {
        const v = validateRuntimeMessage(raw);
        if (!v.ok) return;
        if (v.value.type === "__STATE_CHANGED__" && v.value.payload?.session) {
          const s = v.value.payload.session;
          applySessionState(s);
        } else if (v.value.type === "__STEP_RECORDED__") {
          void refreshControlSteps();
        }
      });
    } catch (e) {
      logger.warn("initRuntimeListener falhou", e);
    }
  }
  function initPageHideGuard() {
    try {
      window.addEventListener("pagehide", onPageHideSoon, true);
      window.addEventListener("beforeunload", onPageHideSoon, true);
    } catch {
    }
  }
  function init() {
    try {
      const locationHref = typeof window !== "undefined" ? window.location?.href ?? "" : "";
      logger.info(
        `content script iniciado readyState=${document?.readyState} location=${locationHref.slice(0, 160)}`
      );
    } catch {
      logger.info("content script iniciado (sem window disponivel)");
    }
    const restriction = getRestrictionInfo();
    state.restricted = !!restriction;
    const boot = () => {
      void (async () => {
        if (restriction) renderBanner(restriction);
        await resolveOwnTabId();
        await fetchInitialState();
        await loadProjectContext();
        initStorageListener();
        initRuntimeListener();
        initPageHideGuard();
      })();
    };
    if (typeof document !== "undefined" && document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", boot, { once: true });
    } else {
      boot();
    }
  }
  var contentGlobal = globalThis;
  if (contentGlobal[CONTENT_INSTANCE_GLOBAL] !== true) {
    contentGlobal[CONTENT_INSTANCE_GLOBAL] = true;
    document.documentElement.setAttribute(CONTENT_INSTANCE_ATTRIBUTE, chrome.runtime.id);
    init();
  } else {
    logger.info("instância duplicada do content script ignorada");
  }
})();
//# sourceMappingURL=index.js.map
