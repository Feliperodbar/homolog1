// src/shared/uuid.ts
function uuidv4() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    try {
      return crypto.randomUUID();
    } catch {
    }
  }
  const bytes = Array.from(
    typeof crypto !== "undefined" && typeof crypto.getRandomValues === "function" ? crypto.getRandomValues(new Uint8Array(16)) : Array.from({ length: 16 }, () => Math.floor(Math.random() * 256))
  );
  bytes[6] = bytes[6] & 15 | 64;
  bytes[8] = bytes[8] & 63 | 128;
  const hex = bytes.map((b) => b.toString(16).padStart(2, "0")).join("");
  return [
    hex.slice(0, 8),
    hex.slice(8, 12),
    hex.slice(12, 16),
    hex.slice(16, 20),
    hex.slice(20, 32)
  ].join("-");
}

// src/shared/stateMachine.ts
function createEmptySession() {
  return {
    sessionId: "",
    state: "idle",
    tabId: null,
    stepCount: 0,
    startedAt: null,
    pausedAt: null,
    endedAt: null,
    lastUpdatedAt: Date.now()
  };
}
function createNewSession(tabId = null, sessionId = uuidv4()) {
  const now = Date.now();
  return {
    sessionId,
    state: "idle",
    tabId,
    stepCount: 0,
    startedAt: null,
    pausedAt: null,
    endedAt: null,
    lastUpdatedAt: now
  };
}
function cloneSession(session) {
  return {
    ...session
  };
}
function _updated(session) {
  return { ...session, lastUpdatedAt: Date.now() };
}
function isValidTransition(state, transition) {
  const m = {
    idle: ["START", "RESET"],
    recording: ["PAUSE", "FINALIZE", "INCREMENT_STEP", "RESET"],
    paused: ["RESUME", "FINALIZE", "RESET"],
    finalized: ["RESET"]
  };
  return m[state].includes(transition);
}
function _nop(session, reason = "no-op") {
  return { session, changed: false, reason };
}
function start(session) {
  const s = cloneSession(session);
  if (s.state === "recording") {
    return _nop(s, "ja esta gravando");
  }
  if (s.state !== "idle") {
    return _nop(s, `start invalido a partir de ${s.state}`);
  }
  const now = Date.now();
  s.state = "recording";
  s.startedAt = s.startedAt ?? now;
  s.pausedAt = null;
  s.endedAt = null;
  return { session: _updated(s), changed: true };
}
function pause(session) {
  const s = cloneSession(session);
  if (s.state === "paused") {
    return _nop(s, "ja esta pausado");
  }
  if (s.state !== "recording") {
    return _nop(s, `pause invalido a partir de ${s.state}`);
  }
  s.state = "paused";
  s.pausedAt = Date.now();
  return { session: _updated(s), changed: true };
}
function resume(session) {
  const s = cloneSession(session);
  if (s.state === "recording") {
    return _nop(s, "ja esta gravando");
  }
  if (s.state !== "paused") {
    return _nop(s, `resume invalido a partir de ${s.state}`);
  }
  s.state = "recording";
  s.pausedAt = null;
  return { session: _updated(s), changed: true };
}
function finalize(session) {
  const s = cloneSession(session);
  if (s.state === "finalized") {
    return _nop(s, "ja finalizado");
  }
  if (s.state !== "recording" && s.state !== "paused") {
    return _nop(s, `finalize invalido a partir de ${s.state}`);
  }
  s.state = "finalized";
  s.pausedAt = null;
  s.endedAt = Date.now();
  return { session: _updated(s), changed: true };
}
function incrementStep(session) {
  const s = cloneSession(session);
  if (s.state !== "recording") {
    return _nop(s, `só e permitido incrementar passos durante gravacao (estado ${s.state})`);
  }
  s.stepCount += 1;
  return { session: _updated(s), changed: true };
}
function reset(session, tabId) {
  const s = createNewSession(tabId ?? session.tabId ?? null);
  return { session: _updated(s), changed: true, reason: "reset" };
}
function applyTransition(session, transition) {
  if (!isValidTransition(session.state, transition)) {
    return {
      session: cloneSession(session),
      changed: false,
      reason: `transicao ${transition} invalida a partir de ${session.state}`
    };
  }
  switch (transition) {
    case "START":
      return start(session);
    case "PAUSE":
      return pause(session);
    case "RESUME":
      return resume(session);
    case "FINALIZE":
      return finalize(session);
    case "INCREMENT_STEP":
      return incrementStep(session);
    case "RESET":
      return reset(session);
  }
}

// src/shared/constants.ts
var STORAGE_KEY_RECORDING = "homolog_recording_v1";
var STORAGE_KEY_LAST_INTERACTION = "homolog_last_interaction_v1";
var STORAGE_KEY_STEPS = "homolog_steps_v1";
var STORAGE_KEY_LAST_STEP = "homolog_last_step_v1";
var STORAGE_KEY_ACTIVE_PROJECT_ID = "homolog_active_project_id_v1";
var STORAGE_KEY_ACTIVE_SESSION_ID = "homolog_active_session_id_v1";
var STORAGE_KEY_IDB_MIGRATION_DONE = "homolog_idb_migration_done_v1";
var SCREENSHOT = {
  FORMAT: "image/jpeg",
  QUALITY: 0.82,
  MAX_WIDTH_PX: 1920,
  TIMEOUT_MS: 4e3,
  // captureVisibleTab possui limite de chamadas no Chromium. Mantemos margem
  // acima de 500 ms para não perder capturas por excesso de frequência.
  MIN_INTERVAL_BETWEEN_CAPTURES_MS: 525,
  POINTER_MARKER_ID: "__homolog_click_marker__",
  POINTER_MARKER_RADIUS_PX: 18,
  POINTER_MARKER_DURATION_MS: 1200,
  MAX_STEPS_IN_STORAGE: 200,
  MAX_DATA_URL_LENGTH: 4 * 1024 * 1024
};
var ACTION_LABELS = {
  click: "clique",
  tap: "toque",
  press: "pressionar",
  unknown: "interacao"
};

// src/shared/messageValidator.ts
var STRING_TYPES = /* @__PURE__ */ new Set([
  "GET_STATE",
  "START",
  "PAUSE",
  "RESUME",
  "FINALIZE",
  "INCREMENT_STEP",
  "RESET",
  "__STATE_CHANGED__",
  "__GET_LAST_INTERACTION__",
  "__GET_LAST_STEP__",
  "__LIST_STEPS__",
  "__DELETE_STEP__",
  "__CLEAR_STEPS__",
  "__GET_PROJECT_CONTEXT__",
  "__SAVE_PROJECT_CONTEXT__",
  "__NEW_PROJECT_CONTEXT__",
  "__OPEN_PANEL_BACKGROUND__",
  "__GET_MY_TAB_ID__",
  "__RECORD_INTERACTION__",
  "__REQUEST_SCREENSHOT__",
  "__STEP_RECORDED__"
]);
function isRecord(x) {
  return !!x && typeof x === "object" && !Array.isArray(x);
}
function isNonEmptyString(x, maxLen = 4096) {
  return typeof x === "string" && x.length >= 1 && x.length <= maxLen;
}
function isFiniteNumber(x, min, max) {
  if (typeof x !== "number" || !Number.isFinite(x)) return false;
  if (typeof min === "number" && x < min) return false;
  if (typeof max === "number" && x > max) return false;
  return true;
}
function isNullableString(x, maxLen = 400) {
  if (x === null || x === void 0) return true;
  return typeof x === "string" && x.length <= maxLen;
}
function isPoint(p) {
  if (!isRecord(p)) return false;
  return isFiniteNumber(p.x, -1e4, 1e5) && isFiniteNumber(p.y, -1e4, 1e5);
}
function isRect(r) {
  if (!isRecord(r)) return false;
  return isFiniteNumber(r.x, -1e4, 1e5) && isFiniteNumber(r.y, -1e4, 1e5) && isFiniteNumber(r.width, 0, 1e5) && isFiniteNumber(r.height, 0, 1e5);
}
function isTarget(t) {
  if (!isRecord(t)) return false;
  if (!isNonEmptyString(t.tagName, 100)) return false;
  if (typeof t.visibleText !== "string" || t.visibleText.length > 2e3) return false;
  if (typeof t.accessibleName !== "string" || t.accessibleName.length > 1e3) return false;
  if (!isNullableString(t.ariaLabel, 500)) return false;
  if (!isNullableString(t.title, 500)) return false;
  if (!isNullableString(t.id, 200)) return false;
  if (!isNullableString(t.name, 200)) return false;
  if (!isNullableString(t.role, 100)) return false;
  if (!isNullableString(t.fieldType, 60)) return false;
  if (!(t.value === null || typeof t.value === "string" && t.value.length <= 400)) return false;
  if (t.sensitivity !== "none" && t.sensitivity !== "password" && t.sensitivity !== "sensitive")
    return false;
  return true;
}
function validateRuntimeMessage(msg) {
  if (!isRecord(msg)) return { ok: false, error: "mensagem nao e objeto" };
  const type = msg.type;
  if (!isNonEmptyString(type, 100) || !STRING_TYPES.has(type)) {
    return { ok: false, error: `tipo de mensagem invalido: ${String(type).slice(0, 80)}` };
  }
  if (msg.payload !== void 0 && msg.payload !== null && !isRecord(msg.payload)) {
    return { ok: false, error: "payload deve ser objeto ou undefined" };
  }
  return { ok: true, value: msg };
}
function validateInteractionEvent(ev) {
  if (!isRecord(ev)) return { ok: false, error: "interacao nao e objeto" };
  if (!isNonEmptyString(ev.interactionId, 128))
    return { ok: false, error: "interactionId invalido" };
  if (!(ev.sessionId === null || isNonEmptyString(ev.sessionId, 200)))
    return { ok: false, error: "sessionId invalido" };
  if (!isTarget(ev.target)) return { ok: false, error: "target invalido" };
  if (!isPoint(ev.viewportPoint)) return { ok: false, error: "viewportPoint invalido" };
  if (!isRect(ev.elementRect)) return { ok: false, error: "elementRect invalido" };
  if (!isNonEmptyString(ev.url, 4096)) return { ok: false, error: "url invalida" };
  if (typeof ev.pageTitle !== "string" || ev.pageTitle.length > 2e3)
    return { ok: false, error: "pageTitle invalido" };
  if (!isRecord(ev.viewportSize) || !isFiniteNumber(ev.viewportSize.width, 0, 1e5) || !isFiniteNumber(ev.viewportSize.height, 0, 1e5)) {
    return { ok: false, error: "viewportSize invalido" };
  }
  if (!isFiniteNumber(ev.devicePixelRatio, 0.1, 10))
    return { ok: false, error: "devicePixelRatio invalido" };
  if (!isFiniteNumber(ev.timestamp)) return { ok: false, error: "timestamp invalido" };
  if (typeof ev.stableSelector !== "string" || ev.stableSelector.length > 1024)
    return { ok: false, error: "stableSelector invalido" };
  if (!["mouse", "touch", "pen", "unknown"].includes(String(ev.inputSource))) {
    return { ok: false, error: "inputSource invalido" };
  }
  if (typeof ev.isTrusted !== "boolean") return { ok: false, error: "isTrusted invalido" };
  return { ok: true, value: ev };
}
function isDataUrlImageLoose(x, maxLen = SCREENSHOT.MAX_DATA_URL_LENGTH) {
  if (typeof x !== "string") return false;
  if (x.length > maxLen) return false;
  return x.startsWith("data:image/jpeg;base64,") || x.startsWith("data:image/png;base64,");
}
function validateRecordingStep(s) {
  if (!isRecord(s)) return { ok: false, error: "step nao e objeto" };
  if (!isNonEmptyString(s.stepId, 128)) return { ok: false, error: "stepId invalido" };
  if (!isNonEmptyString(s.sessionId, 200)) return { ok: false, error: "sessionId invalido" };
  if (!isFiniteNumber(s.sequence, 1, 1e6)) return { ok: false, error: "sequence invalida" };
  if (!["click", "tap", "press", "unknown"].includes(String(s.actionType))) {
    return { ok: false, error: "actionType invalido" };
  }
  if (!isNonEmptyString(s.interactionId, 128))
    return { ok: false, error: "interactionId invalido" };
  if (!isTarget(s.target)) return { ok: false, error: "step target invalido" };
  if (!isPoint(s.viewportPoint)) return { ok: false, error: "step viewportPoint invalido" };
  if (!isRect(s.elementRect)) return { ok: false, error: "step elementRect invalido" };
  if (!isNonEmptyString(s.url, 4096)) return { ok: false, error: "step url invalida" };
  if (typeof s.pageTitle !== "string" || s.pageTitle.length > 2e3)
    return { ok: false, error: "step pageTitle invalido" };
  if (!isRecord(s.viewportSize) || !isFiniteNumber(s.viewportSize.width, 0, 1e5) || !isFiniteNumber(s.viewportSize.height, 0, 1e5)) {
    return { ok: false, error: "step viewportSize invalido" };
  }
  if (!isFiniteNumber(s.devicePixelRatio, 0.1, 10))
    return { ok: false, error: "step devicePixelRatio invalido" };
  if (typeof s.stableSelector !== "string" || s.stableSelector.length > 1024)
    return { ok: false, error: "step stableSelector invalido" };
  if (!["mouse", "touch", "pen", "unknown"].includes(String(s.inputSource))) {
    return { ok: false, error: "step inputSource invalido" };
  }
  if (!isDataUrlImageLoose(s.screenshotDataUrl))
    return { ok: false, error: "step screenshotDataUrl invalido" };
  if (s.screenshotFormat !== "image/png" && s.screenshotFormat !== "image/jpeg")
    return { ok: false, error: "step screenshotFormat invalido" };
  if (!isFiniteNumber(s.screenshotWidthPx, 0, 1e5))
    return { ok: false, error: "step screenshotWidthPx invalido" };
  if (!isFiniteNumber(s.screenshotHeightPx, 0, 1e5))
    return { ok: false, error: "step screenshotHeightPx invalido" };
  if (!isFiniteNumber(s.screenshotSizeBytes, 0, 256 * 1024 * 1024))
    return { ok: false, error: "step screenshotSizeBytes invalido" };
  if (!isNonEmptyString(s.description, 1024))
    return { ok: false, error: "step description invalida" };
  if (!isFiniteNumber(s.timestamp)) return { ok: false, error: "step timestamp invalido" };
  if (!(s.tabId === null || typeof s.tabId === "number"))
    return { ok: false, error: "step tabId invalido" };
  if (typeof s.isTrusted !== "boolean") return { ok: false, error: "step isTrusted invalido" };
  return { ok: true, value: s };
}

// src/shared/screenshotUtils.ts
var DATA_URL_PREFIX_JPEG = "data:image/jpeg;base64,";
var DATA_URL_PREFIX_PNG = "data:image/png;base64,";
function isDataUrlImage(v) {
  if (typeof v !== "string") return false;
  if (v.length > SCREENSHOT.MAX_DATA_URL_LENGTH) return false;
  return v.startsWith(DATA_URL_PREFIX_JPEG) || v.startsWith(DATA_URL_PREFIX_PNG);
}
function detectDataUrlFormat(dataUrl) {
  if (dataUrl.startsWith(DATA_URL_PREFIX_PNG)) return "image/png";
  return "image/jpeg";
}
function estimateDataUrlBytes(dataUrl) {
  if (typeof dataUrl !== "string") return 0;
  const comma = dataUrl.indexOf(",");
  const base64 = comma >= 0 ? dataUrl.slice(comma + 1) : dataUrl;
  const pad = base64.endsWith("==") ? 2 : base64.endsWith("=") ? 1 : 0;
  return Math.max(0, Math.floor(base64.length * 3 / 4) - pad);
}
async function compressScreenshotDataUrl(input, opts) {
  if (typeof input !== "string") return null;
  if (typeof document === "undefined" || typeof Image !== "function") {
    if (isDataUrlImage(input)) {
      const format2 = detectDataUrlFormat(input);
      return {
        dataUrl: input,
        format: format2,
        widthPx: 0,
        heightPx: 0,
        bytes: estimateDataUrlBytes(input)
      };
    }
    return null;
  }
  const maxWidth = opts?.maxWidthPx ?? SCREENSHOT.MAX_WIDTH_PX;
  const format = opts?.format ?? SCREENSHOT.FORMAT;
  const quality = opts?.quality ?? SCREENSHOT.QUALITY;
  try {
    const img = await new Promise((resolve, reject) => {
      const im = new Image();
      im.onload = () => resolve(im);
      im.onerror = () => reject(new Error("image decode error"));
      im.src = input;
    });
    if (!img.naturalWidth || !img.naturalHeight) return null;
    let targetWidth = img.naturalWidth;
    let targetHeight = img.naturalHeight;
    if (targetWidth > maxWidth) {
      const ratio = maxWidth / targetWidth;
      targetWidth = maxWidth;
      targetHeight = Math.max(1, Math.round(img.naturalHeight * ratio));
    }
    const canvas = document.createElement("canvas");
    canvas.width = targetWidth;
    canvas.height = targetHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(img, 0, 0, targetWidth, targetHeight);
    const dataUrl = format === "image/jpeg" ? canvas.toDataURL("image/jpeg", quality) : canvas.toDataURL("image/png");
    return {
      dataUrl,
      format,
      widthPx: targetWidth,
      heightPx: targetHeight,
      bytes: estimateDataUrlBytes(dataUrl)
    };
  } catch {
    if (isDataUrlImage(input)) {
      const fmt = detectDataUrlFormat(input);
      return {
        dataUrl: input,
        format: fmt,
        widthPx: 0,
        heightPx: 0,
        bytes: estimateDataUrlBytes(input)
      };
    }
    return null;
  }
}
function friendlyRoleOrTag(t) {
  const role = (t.role ?? "").toLowerCase().trim();
  if (role) {
    switch (role) {
      case "button":
        return "botão";
      case "link":
        return "link";
      case "checkbox":
        return "checkbox";
      case "radio":
        return "radio";
      case "textbox":
        return "campo de texto";
      case "searchbox":
        return "campo de busca";
      case "combobox":
        return "combobox";
      case "tab":
        return "aba";
      case "menuitem":
        return "item de menu";
      default:
        return role;
    }
  }
  const tag = (t.tagName ?? "").toLowerCase().trim();
  switch (tag) {
    case "button":
      return "botão";
    case "a":
      return "link";
    case "input": {
      const tp = (t.fieldType ?? "").toLowerCase();
      if (tp === "submit" || tp === "button" || tp === "reset") return "botão";
      if (tp === "checkbox") return "checkbox";
      if (tp === "radio") return "radio";
      if (tp === "email") return "campo de e-mail";
      if (tp === "password") return "campo de senha";
      if (tp === "search") return "campo de busca";
      if (tp === "tel") return "campo de telefone";
      if (tp === "number") return "campo numérico";
      return "campo de texto";
    }
    case "select":
      return "combobox";
    case "textarea":
      return "área de texto";
    case "label":
      return "rótulo";
    case "img":
      return "imagem";
    case "li":
      return "item de lista";
    case "h1":
    case "h2":
    case "h3":
    case "h4":
    case "h5":
    case "h6":
      return "título";
    case "td":
    case "th":
      return "célula de tabela";
    default:
      return tag || "elemento";
  }
}
function bestElementName(t) {
  const candidates = [t.accessibleName, t.ariaLabel, t.visibleText, t.title, t.id];
  for (const c of candidates) {
    const v = (c ?? "").replace(/\s+/g, " ").trim();
    if (v.length >= 1 && v.length <= 120) return v;
  }
  return null;
}
function actionVerbFor(action, inputSource) {
  if (action === "tap" || inputSource === "touch") return "Tocar";
  if (inputSource === "pen" || action === "press") return "Pressionar";
  return "Clicar";
}
function buildAutomaticDescription(interaction) {
  const action = interaction.actionType ?? "click";
  const verb = actionVerbFor(action, interaction.inputSource);
  const kind = friendlyRoleOrTag(interaction.target);
  const name = bestElementName(interaction.target);
  const _label = ACTION_LABELS[action] ?? "interacao";
  if (name) {
    return `${verb} no ${kind} “${name}”.`;
  }
  return `${verb} no ${kind}.`;
}
function actionTypeFromInputSource(src) {
  switch (src) {
    case "touch":
      return "tap";
    case "pen":
      return "press";
    case "mouse":
      return "click";
    default:
      return "unknown";
  }
}
function buildRecordingStep(p) {
  if (!p.interaction?.interactionId) return null;
  if (!isDataUrlImage(p.screenshotDataUrl) && !p.compressed) return null;
  const compressed = p.compressed ?? {
    dataUrl: p.screenshotDataUrl,
    format: detectDataUrlFormat(p.screenshotDataUrl),
    widthPx: 0,
    heightPx: 0,
    bytes: estimateDataUrlBytes(p.screenshotDataUrl)
  };
  const actionType = actionTypeFromInputSource(p.interaction.inputSource);
  const description = buildAutomaticDescription({ ...p.interaction, actionType });
  const sessionId = p.sessionId ?? p.interaction.sessionId ?? "";
  if (!sessionId) return null;
  const step = {
    stepId: uuidv4(),
    sessionId,
    sequence: Number.isFinite(p.sequence) && p.sequence > 0 ? p.sequence : 1,
    actionType,
    interactionId: p.interaction.interactionId,
    target: p.interaction.target,
    viewportPoint: p.interaction.viewportPoint,
    elementRect: p.interaction.elementRect,
    url: p.interaction.url,
    pageTitle: p.interaction.pageTitle,
    viewportSize: p.interaction.viewportSize,
    devicePixelRatio: p.interaction.devicePixelRatio,
    stableSelector: p.interaction.stableSelector,
    inputSource: p.interaction.inputSource,
    screenshotDataUrl: compressed.dataUrl,
    screenshotFormat: compressed.format,
    screenshotWidthPx: compressed.widthPx,
    screenshotHeightPx: compressed.heightPx,
    screenshotSizeBytes: compressed.bytes,
    description,
    timestamp: p.interaction.timestamp,
    tabId: p.tabId ?? null,
    isTrusted: p.interaction.isTrusted
  };
  return step;
}

// src/shared/storage/types.ts
var DB_NAME = "homolog_main_v1";
var DB_VERSION = 2;
var STORE = {
  PROJECTS: "projects",
  SESSIONS: "sessions",
  STEPS: "steps",
  SCREENSHOTS: "screenshots",
  SETTINGS: "settings"
};
var STORE_LIST = [
  STORE.PROJECTS,
  STORE.SESSIONS,
  STORE.STEPS,
  STORE.SCREENSHOTS,
  STORE.SETTINGS
];
var INDEX = {
  SESSIONS_BY_PROJECT: "by_projectId_createdAt",
  STEPS_BY_SESSION: "by_sessionId_sequence",
  STEPS_BY_SESSION_CREATED: "by_sessionId_createdAt",
  SCREENSHOTS_BY_STEP: "by_stepId"
};

// src/shared/storage/idbConnection.ts
var singleton = {
  db: null,
  closed: false,
  openPromise: null
};
function createStores(db) {
  if (!db.objectStoreNames.contains(STORE.PROJECTS)) {
    const projects = db.createObjectStore(STORE.PROJECTS, { keyPath: "projectId" });
    projects.createIndex("by_updatedAt", "updatedAt", { unique: false });
    projects.createIndex("by_createdAt", "createdAt", { unique: false });
    projects.createIndex("by_name", "name", { unique: false });
  }
  if (!db.objectStoreNames.contains(STORE.SESSIONS)) {
    const sessions = db.createObjectStore(STORE.SESSIONS, { keyPath: "sessionId" });
    sessions.createIndex(INDEX.SESSIONS_BY_PROJECT, ["projectId", "createdAt"], { unique: false });
    sessions.createIndex("by_projectId_state", ["projectId", "state"], { unique: false });
    sessions.createIndex("by_updatedAt", "updatedAt", { unique: false });
  }
  if (!db.objectStoreNames.contains(STORE.STEPS)) {
    const steps = db.createObjectStore(STORE.STEPS, { keyPath: "stepId" });
    steps.createIndex(INDEX.STEPS_BY_SESSION, ["sessionId", "sequence"], { unique: true });
    steps.createIndex(INDEX.STEPS_BY_SESSION_CREATED, ["sessionId", "timestamp"], { unique: false });
    steps.createIndex("by_sessionId_screenshotId", ["sessionId", "screenshotId"], { unique: false });
    steps.createIndex("by_projectId", "projectId", { unique: false });
  }
  if (!db.objectStoreNames.contains(STORE.SCREENSHOTS)) {
    const shots = db.createObjectStore(STORE.SCREENSHOTS, { keyPath: "screenshotId" });
    shots.createIndex(INDEX.SCREENSHOTS_BY_STEP, ["stepId"], { unique: true });
    shots.createIndex("by_sessionId", "sessionId", { unique: false });
    shots.createIndex("by_projectId", "projectId", { unique: false });
  }
  if (!db.objectStoreNames.contains(STORE.SETTINGS)) {
    db.createObjectStore(STORE.SETTINGS, { keyPath: "key" });
  }
}
async function openDatabase(options = {}) {
  const name = options.name ?? DB_NAME;
  const version = options.version ?? DB_VERSION;
  if (singleton.db && !singleton.closed && !options.allowNewConnectionOnly) {
    return singleton.db;
  }
  if (singleton.openPromise && !options.allowNewConnectionOnly) {
    return singleton.openPromise;
  }
  const p = new Promise((resolve, reject) => {
    try {
      const req = indexedDB.open(name, version);
      req.onupgradeneeded = (ev) => {
        const db = req.result;
        const oldVersion = ev.oldVersion ?? 0;
        const newVersion = ev.newVersion ?? DB_VERSION;
        if (oldVersion < 1) {
          createStores(db);
        }
        if (typeof db.onupgradeneeded === "undefined") {
        }
      };
      req.onsuccess = () => {
        const db = req.result;
        db.onclose = () => {
          singleton.closed = true;
        };
        db.onversionchange = () => {
          try {
            db.close();
          } catch {
          }
          singleton.closed = true;
          singleton.db = null;
        };
        singleton.db = db;
        singleton.closed = false;
        singleton.openPromise = null;
        resolve(db);
      };
      req.onerror = () => {
        singleton.openPromise = null;
        reject(req.error ?? new Error("openDatabase erro desconhecido"));
      };
      req.onblocked = () => {
        singleton.openPromise = null;
        reject(new Error("openDatabase bloqueado por outra conexao (feche outras abas/popup)"));
      };
    } catch (e) {
      singleton.openPromise = null;
      reject(e instanceof Error ? e : new Error(String(e)));
    }
  });
  if (!options.allowNewConnectionOnly) singleton.openPromise = p.catch(() => null);
  return p;
}
function getKeyRange() {
  const gt = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof self !== "undefined" ? self : null;
  if (gt?.IDBKeyRange && typeof gt.IDBKeyRange.only === "function") {
    return gt.IDBKeyRange;
  }
  if (typeof IDBKeyRange !== "undefined" && typeof IDBKeyRange.only === "function") {
    return IDBKeyRange;
  }
  const fdbAsAny = indexedDB;
  if (fdbAsAny.IDBKeyRange && typeof fdbAsAny.IDBKeyRange.only === "function") {
    return fdbAsAny.IDBKeyRange;
  }
  throw new Error(
    "IndexedDB KeyRange indisponivel neste ambiente. Verifique se a polyfill foi carregada."
  );
}
function wrapRequest(req) {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("IDBRequest erro"));
  });
}
async function withTransaction(stores, mode, fn) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const storeNames = Array.isArray(stores) ? stores : [stores];
    const tx = db.transaction(storeNames, mode);
    let result;
    let resolved = false;
    let asyncError = null;
    let callbackCompleted = false;
    let _callbackWasAsync = false;
    let txCompleted = false;
    const finishOnce = (kind, valueOrErr) => {
      if (resolved) return;
      resolved = true;
      if (kind === "ok") resolve(valueOrErr);
      else reject(valueOrErr);
    };
    const tryFinish = () => {
      if (resolved) return;
      if (!callbackCompleted || !txCompleted) return;
      if (asyncError) {
        finishOnce("err", asyncError);
      } else {
        finishOnce("ok", result);
      }
    };
    tx.onerror = () => {
      txCompleted = true;
      asyncError = asyncError ?? tx.error ?? new Error("transaction erro desconhecido");
      tryFinish();
    };
    tx.onabort = () => {
      txCompleted = true;
      asyncError = asyncError ?? tx.error ?? new Error("transaction abortada");
      tryFinish();
    };
    tx.oncomplete = () => {
      txCompleted = true;
      tryFinish();
    };
    try {
      const out = fn(tx);
      if (out && typeof out.then === "function") {
        _callbackWasAsync = true;
        out.then((r) => {
          result = r;
          callbackCompleted = true;
          tryFinish();
        }).catch((e) => {
          asyncError = e;
          callbackCompleted = true;
          try {
            tx.abort();
          } catch {
          }
          tryFinish();
        });
      } else {
        result = out;
        callbackCompleted = true;
      }
    } catch (e) {
      asyncError = e;
      callbackCompleted = true;
      try {
        tx.abort();
      } catch {
      }
      txCompleted = true;
      finishOnce("err", e);
    }
  });
}

// src/shared/storage/blobUtils.ts
var __BLOB_BYTES_CACHE__ = (() => {
  try {
    return /* @__PURE__ */ new WeakMap();
  } catch {
    return /* @__PURE__ */ new Map();
  }
})();
function cacheBlobBytes(blob, bytes, mime) {
  try {
    __BLOB_BYTES_CACHE__.set(blob, { bytes, mime });
  } catch {
  }
  try {
    Object.defineProperty(blob, "__homolog_u8bytes", {
      value: bytes,
      writable: false,
      configurable: true,
      enumerable: false
    });
    Object.defineProperty(blob, "__homolog_mime", {
      value: mime,
      writable: false,
      configurable: true,
      enumerable: false
    });
  } catch {
  }
}
function getCachedBlobBytes(blob) {
  try {
    const weak = __BLOB_BYTES_CACHE__.get(blob);
    if (weak && weak.bytes && weak.bytes.length >= 0) return weak;
  } catch {
  }
  try {
    const b = blob.__homolog_u8bytes;
    const m = blob.__homolog_mime;
    if (b && b.length >= 0) return { bytes: b, mime: typeof m === "string" ? m : blob.type || "application/octet-stream" };
  } catch {
  }
  return null;
}
function base64FromDataUrl(dataUrl) {
  try {
    const match = /^data:([^;,]+)(?:;charset=[^;,]*)?;base64,(.*)$/.exec(String(dataUrl ?? ""));
    if (!match) return null;
    return { mime: match[1], base64: match[2] };
  } catch {
    return null;
  }
}
function dataUrlToUint8AndMime(dataUrl) {
  const parsed = base64FromDataUrl(dataUrl);
  if (!parsed) {
    throw new Error("dataURL invalido (esperado data:image/<png|jpeg>;base64,...)");
  }
  return { bytes: base64ToUint8(parsed.base64), mime: parsed.mime };
}
function base64ToUint8(base64) {
  const clean = String(base64 ?? "").replace(/\s+/g, "");
  const hasBuffer = typeof Buffer !== "undefined" && typeof Buffer.from === "function";
  if (hasBuffer) {
    try {
      const buf = Buffer.from(
        clean,
        "base64"
      );
      return new Uint8Array(buf);
    } catch {
    }
  }
  if (typeof atob === "function") {
    const binStr = atob(clean);
    const len = binStr.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i += 1) bytes[i] = binStr.charCodeAt(i);
    return bytes;
  }
  return new Uint8Array(0);
}
function bytesToBase64(bytes) {
  if (!bytes || bytes.length === 0) return "";
  const hasBuffer = typeof Buffer !== "undefined" && typeof Buffer.from === "function";
  if (hasBuffer) {
    try {
      const buf = Buffer.from(
        bytes,
        "binary"
      );
      return buf.toString("base64");
    } catch {
    }
  }
  if (typeof btoa === "function") {
    try {
      let binary = "";
      const chunkSize = 32768;
      for (let i = 0; i < bytes.length; i += chunkSize) {
        const chunk = bytes.subarray(i, i + chunkSize);
        binary += String.fromCharCode.apply(null, Array.from(chunk));
      }
      return btoa(binary);
    } catch {
    }
  }
  try {
    const uint8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    const len = uint8.length;
    let out = "";
    const map = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for (let i = 0; i < len; i += 3) {
      const b1 = uint8[i];
      const b2 = i + 1 < len ? uint8[i + 1] : 0;
      const b3 = i + 2 < len ? uint8[i + 2] : 0;
      const triple = b1 << 16 | b2 << 8 | b3;
      out += map[triple >> 18 & 63];
      out += map[triple >> 12 & 63];
      out += i + 1 < len ? map[triple >> 6 & 63] : "=";
      out += i + 2 < len ? map[triple & 63] : "=";
    }
    return out;
  } catch {
    return "";
  }
}
async function blobToDataUrl(blob) {
  const cached = getCachedBlobBytes(blob);
  if (cached && cached.bytes.length > 0) {
    const base64 = bytesToBase64(cached.bytes);
    return `data:${cached.mime};base64,${base64}`;
  }
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result ?? "");
      try {
        const parsed = base64FromDataUrl(dataUrl);
        if (parsed) cacheBlobBytes(blob, base64ToUint8(parsed.base64), parsed.mime);
      } catch {
      }
      resolve(dataUrl);
    };
    reader.onerror = () => reject(reader.error ?? new Error("FileReader erro"));
    reader.readAsDataURL(blob);
  });
}
function detectImageMimeOrDefault(value, fallback = "image/jpeg") {
  if (typeof value === "string") {
    const v = value.toLowerCase();
    if (v.startsWith("data:image/png")) return "image/png";
    if (v.startsWith("data:image/jpeg")) return "image/jpeg";
    return fallback;
  }
  if (value instanceof Blob) {
    const t = (value.type || "").toLowerCase();
    if (t === "image/png") return "image/png";
    if (t === "image/jpeg") return "image/jpeg";
    return fallback;
  }
  return fallback;
}
async function readBlobDimensions(blob) {
  if (typeof createImageBitmap === "function") {
    try {
      const bmp = await createImageBitmap(blob);
      const { width, height } = bmp;
      try {
        bmp.close?.();
      } catch {
      }
      return { widthPx: width, heightPx: height };
    } catch {
    }
  }
  if (typeof Image !== "undefined" && typeof URL !== "undefined" && typeof URL.createObjectURL === "function" && typeof URL.revokeObjectURL === "function") {
    return new Promise((resolve) => {
      const url = URL.createObjectURL(blob);
      const img = new Image();
      const cleanup = () => {
        try {
          URL.revokeObjectURL(url);
        } catch {
        }
      };
      img.onload = () => {
        const r = { widthPx: img.naturalWidth || img.width || 0, heightPx: img.naturalHeight || img.height || 0 };
        cleanup();
        resolve(r);
      };
      img.onerror = () => {
        cleanup();
        resolve({ widthPx: 0, heightPx: 0 });
      };
      img.src = url;
    });
  }
  return { widthPx: 0, heightPx: 0 };
}
function normalizeBytes(bytesLike) {
  if (bytesLike instanceof Uint8Array) return bytesLike;
  if (bytesLike instanceof ArrayBuffer) return new Uint8Array(bytesLike);
  if (typeof SharedArrayBuffer !== "undefined" && bytesLike instanceof SharedArrayBuffer) {
    return new Uint8Array(bytesLike);
  }
  if (bytesLike && typeof bytesLike === "object" && typeof bytesLike.buffer !== "undefined") {
    try {
      const view = bytesLike;
      if (typeof view.byteLength === "number" && typeof view.byteOffset === "number" && view.buffer) {
        return new Uint8Array(view.buffer, view.byteOffset, view.byteLength);
      }
    } catch {
    }
  }
  if (bytesLike && typeof bytesLike === "object") {
    try {
      const len = bytesLike.length ?? -1;
      if (len >= 0 && len < 5e8) {
        const u8 = new Uint8Array(len);
        const src = bytesLike;
        for (let i = 0; i < len; i += 1) {
          u8[i] = (src[i] | 0) & 255;
        }
        return u8;
      }
    } catch {
    }
  }
  if (Array.isArray(bytesLike)) {
    try {
      return new Uint8Array(bytesLike.map((v) => Number(v ?? 0) & 255));
    } catch {
    }
  }
  return new Uint8Array(0);
}
async function blobToUint8Array(blob) {
  if (blob instanceof Uint8Array) return blob;
  const cached = getCachedBlobBytes(blob);
  if (cached && cached.bytes.length > 0) return cached.bytes.slice();
  const asAny = blob;
  if (typeof asAny.arrayBuffer === "function") {
    try {
      const buf = await asAny.arrayBuffer();
      const u8 = new Uint8Array(buf);
      cacheBlobBytes(blob, u8, blob.type || "application/octet-stream");
      return u8;
    } catch {
    }
  }
  if (asAny._buffer && asAny._buffer.buffer) {
    try {
      return new Uint8Array(asAny._buffer.buffer, asAny._buffer.byteOffset ?? 0, asAny._buffer.length ?? 0);
    } catch {
    }
  }
  try {
    if (typeof Response !== "undefined") {
      const buf = await new Response(blob).arrayBuffer();
      return new Uint8Array(buf);
    }
  } catch {
  }
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const buf = reader.result;
      resolve(buf ? new Uint8Array(buf) : new Uint8Array(0));
    };
    reader.onerror = () => reject(reader.error ?? new Error("FileReader erro (blobToUint8Array)"));
    reader.readAsArrayBuffer(blob);
  });
}
function uint8ArrayToBlob(input, mime) {
  const safeBytes = normalizeBytes(input);
  const m = (mime || "application/octet-stream").toString();
  const copiedBytes = new Uint8Array(safeBytes.byteLength);
  copiedBytes.set(safeBytes);
  const blob = new Blob([copiedBytes.buffer], { type: m });
  cacheBlobBytes(blob, safeBytes, m);
  return blob;
}

// src/shared/storage/repository.ts
function screenshotFromPersisted(persisted) {
  const mimeOrFmt = persisted.imageMime || persisted.format || "image/jpeg";
  const rawBytes = persisted.imageBytes;
  let image;
  if (rawBytes instanceof ArrayBuffer) {
    image = uint8ArrayToBlob(new Uint8Array(rawBytes), mimeOrFmt);
  } else if (ArrayBuffer.isView(rawBytes)) {
    const view = rawBytes;
    image = uint8ArrayToBlob(
      new Uint8Array(view.buffer, view.byteOffset, view.byteLength),
      mimeOrFmt
    );
  } else if (Array.isArray(rawBytes)) {
    image = uint8ArrayToBlob(new Uint8Array(rawBytes), mimeOrFmt);
  } else if (persisted.image instanceof Blob) {
    image = persisted.image;
  } else {
    image = new Blob([new Uint8Array(0)], { type: mimeOrFmt });
  }
  return {
    screenshotId: persisted.screenshotId,
    stepId: persisted.stepId,
    sessionId: persisted.sessionId,
    projectId: persisted.projectId,
    image,
    format: persisted.format,
    widthPx: persisted.widthPx,
    heightPx: persisted.heightPx,
    sizeBytes: persisted.sizeBytes,
    createdAt: persisted.createdAt
  };
}
var saveState = {
  status: "idle",
  pendingCount: 0,
  lastSavedAt: null,
  lastError: null,
  listeners: /* @__PURE__ */ new Set()
};
function emitSave() {
  const snap = getSaveIndicatorSnapshot();
  for (const cb of Array.from(saveState.listeners)) {
    try {
      cb(snap);
    } catch {
    }
  }
}
function getSaveIndicatorSnapshot() {
  return {
    status: saveState.status,
    pendingCount: saveState.pendingCount,
    lastSavedAt: saveState.lastSavedAt,
    lastError: saveState.lastError
  };
}
function subscribeSaveIndicator(cb) {
  saveState.listeners.add(cb);
  cb(getSaveIndicatorSnapshot());
  return () => {
    saveState.listeners.delete(cb);
  };
}
function beginSave() {
  saveState.pendingCount += 1;
  saveState.status = "saving";
  emitSave();
}
function endSave(err) {
  saveState.pendingCount = Math.max(0, saveState.pendingCount - 1);
  if (err) {
    saveState.status = "error";
    saveState.lastError = err;
  } else if (saveState.pendingCount === 0) {
    saveState.status = "saved";
    saveState.lastSavedAt = Date.now();
    saveState.lastError = null;
  } else {
    saveState.status = "saving";
  }
  emitSave();
}
function friendlyStorageError(cause, operation) {
  const q = /quota/i.test(cause instanceof Error ? cause.message : String(cause ?? ""));
  const msg = q ? `Armazenamento cheio (Quota excedida) ao ${operation}. Libere espaço excluindo sessões antigas ou exporte backup.` : `Erro ao ${operation}: ${cause instanceof Error ? cause.message : String(cause ?? "desconhecido")}`;
  const e = new Error(msg);
  e.code = q ? "ERR_STORAGE_QUOTA" : "ERR_STORAGE_OP";
  e.cause = cause;
  return e;
}
async function createProject(input) {
  beginSave();
  try {
    await openDatabase();
    const now = Date.now();
    const project = {
      projectId: uuidv4(),
      name: String(input.name || "Projeto sem nome").slice(0, 200),
      description: input.description ?? null,
      color: input.color ?? null,
      createdAt: now,
      updatedAt: now,
      archivedAt: null,
      metadata: input.metadata ?? {}
    };
    await withTransaction(STORE.PROJECTS, "readwrite", (tx) => {
      const store = tx.objectStore(STORE.PROJECTS);
      return wrapRequest(store.put(project));
    });
    endSave();
    return project;
  } catch (e) {
    endSave(e instanceof Error ? e.message : String(e));
    throw friendlyStorageError(e, "criar projeto");
  }
}
async function updateProject(projectId, patch) {
  beginSave();
  try {
    const proj = await getProjectById(projectId);
    if (!proj) throw new Error(`projeto ${projectId} nao existe`);
    const updated = {
      ...proj,
      ...patch,
      projectId: proj.projectId,
      createdAt: proj.createdAt,
      updatedAt: Date.now()
    };
    await withTransaction(
      STORE.PROJECTS,
      "readwrite",
      (tx) => wrapRequest(tx.objectStore(STORE.PROJECTS).put(updated))
    );
    endSave();
    return updated;
  } catch (e) {
    endSave(e instanceof Error ? e.message : String(e));
    throw friendlyStorageError(e, "atualizar projeto");
  }
}
async function getProjectById(projectId) {
  try {
    await openDatabase();
    return await withTransaction(
      STORE.PROJECTS,
      "readonly",
      (tx) => wrapRequest(tx.objectStore(STORE.PROJECTS).get(projectId)).then(
        (v) => v ?? null
      )
    );
  } catch (e) {
    throw friendlyStorageError(e, "ler projeto");
  }
}
async function listProjects(opts = {}) {
  try {
    await openDatabase();
    const includeArchived = !!opts.includeArchived;
    const sortBy = opts.sortBy ?? "updatedAt";
    const limit = typeof opts.limit === "number" ? opts.limit : void 0;
    return await withTransaction(STORE.PROJECTS, "readonly", (tx) => {
      return new Promise((resolve, reject) => {
        const store = tx.objectStore(STORE.PROJECTS);
        let source = store;
        if (sortBy === "name") source = store.index("by_name");
        else if (sortBy === "createdAt") source = store.index("by_createdAt");
        else source = store.index("by_updatedAt");
        const cursorReq = source.openCursor(null, "prev");
        const out = [];
        cursorReq.onsuccess = () => {
          const cursor = cursorReq.result;
          if (!cursor) return resolve(out);
          const v = cursor.value;
          if (!includeArchived && v.archivedAt) {
            cursor.continue();
            return;
          }
          out.push(v);
          if (limit !== void 0 && out.length >= limit) return resolve(out);
          cursor.continue();
        };
        cursorReq.onerror = () => reject(cursorReq.error ?? new Error("cursor falhou"));
      });
    });
  } catch (e) {
    throw friendlyStorageError(e, "listar projetos");
  }
}
async function upsertSessionFromRecordingSession(projectId, rs, opts) {
  beginSave();
  try {
    await openDatabase();
    const existing = await getSessionById(rs.sessionId);
    const now = Date.now();
    if (existing && existing.projectId !== projectId) {
      throw new Error("sessao pertence a outro projeto (projectId divergente)");
    }
    const sess = existing ? {
      ...existing,
      state: rs.state,
      tabId: rs.tabId ?? existing.tabId,
      stepCount: rs.stepCount ?? existing.stepCount,
      startedAt: rs.startedAt ?? existing.startedAt,
      endedAt: rs.endedAt ?? existing.endedAt,
      updatedAt: now,
      durationMs: rs.durationMs ?? existing.durationMs,
      name: opts?.name ?? existing.name,
      description: opts?.description ?? existing.description
    } : {
      sessionId: rs.sessionId,
      projectId,
      name: opts?.name ? String(opts.name).slice(0, 200) : `Sessão ${new Date(now).toLocaleString("pt-BR")}`,
      description: opts?.description ?? null,
      state: rs.state,
      tabId: rs.tabId ?? null,
      stepCount: rs.stepCount ?? 0,
      startedAt: rs.startedAt ?? now,
      endedAt: rs.endedAt ?? null,
      createdAt: rs.createdAt ?? now,
      updatedAt: rs.updatedAt ?? now,
      durationMs: rs.durationMs ?? 0,
      metadata: {}
    };
    await withTransaction(
      STORE.SESSIONS,
      "readwrite",
      (tx) => wrapRequest(tx.objectStore(STORE.SESSIONS).put(sess))
    );
    endSave();
    return sess;
  } catch (e) {
    endSave(e instanceof Error ? e.message : String(e));
    throw friendlyStorageError(e, "persistir sessao");
  }
}
async function getSessionById(sessionId) {
  try {
    await openDatabase();
    return await withTransaction(
      STORE.SESSIONS,
      "readonly",
      (tx) => wrapRequest(tx.objectStore(STORE.SESSIONS).get(sessionId)).then(
        (v) => v ?? null
      )
    );
  } catch (e) {
    throw friendlyStorageError(e, "ler sessao");
  }
}
async function listSessionsByProject(projectId) {
  try {
    await openDatabase();
    return await withTransaction(STORE.SESSIONS, "readonly", (tx) => {
      return new Promise((resolve, reject) => {
        const idx = tx.objectStore(STORE.SESSIONS).index(INDEX.SESSIONS_BY_PROJECT);
        const range = getKeyRange().lowerBound([projectId]);
        const cursorReq = idx.openCursor(range, "prev");
        const out = [];
        cursorReq.onsuccess = () => {
          const cursor = cursorReq.result;
          if (!cursor) return resolve(out.reverse());
          const val = cursor.value;
          if (val.projectId !== projectId) return resolve(out.reverse());
          out.push(val);
          cursor.continue();
        };
        cursorReq.onerror = () => reject(cursorReq.error ?? new Error("cursor falhou"));
      });
    });
  } catch (e) {
    throw friendlyStorageError(e, "listar sessoes");
  }
}
async function addStepWithScreenshot(projectId, sessionId, stepLike, screenshotBlob) {
  beginSave();
  try {
    await openDatabase();
    const now = stepLike.timestamp || Date.now();
    const screenshotId = screenshotBlob ? uuidv4() : null;
    const format = detectImageMimeOrDefault(
      screenshotBlob ?? stepLike.screenshotFormat ?? "image/jpeg",
      "image/jpeg"
    );
    const step = {
      stepId: stepLike.stepId ?? uuidv4(),
      sessionId,
      projectId,
      sequence: stepLike.sequence,
      actionType: stepLike.actionType ?? "unknown",
      interactionId: stepLike.interactionId,
      screenshotId,
      target: stepLike.target,
      stableSelector: stepLike.stableSelector ?? null,
      url: stepLike.url,
      pageTitle: stepLike.pageTitle ?? "",
      viewportPoint: { ...stepLike.viewportPoint },
      elementRect: { ...stepLike.elementRect },
      viewportSize: { ...stepLike.viewportSize },
      devicePixelRatio: stepLike.devicePixelRatio ?? 1,
      description: stepLike.description ?? "",
      timestamp: now,
      inputSource: stepLike.inputSource ?? "unknown",
      tabId: stepLike.tabId ?? null,
      isTrusted: !!stepLike.isTrusted,
      metadata: {}
    };
    let screenshot = null;
    let screenshotPersistedBytes = null;
    let screenshotPersistedMime = format;
    if (screenshotBlob && screenshotId) {
      screenshotPersistedBytes = await blobToUint8Array(screenshotBlob);
      screenshotPersistedMime = screenshotBlob?.type || detectImageMimeOrDefault(screenshotBlob, "image/jpeg");
      const { widthPx, heightPx } = stepLike.screenshotWidthPx && stepLike.screenshotHeightPx ? { widthPx: stepLike.screenshotWidthPx, heightPx: stepLike.screenshotHeightPx } : await readBlobDimensions(screenshotBlob);
      screenshot = {
        screenshotId,
        stepId: step.stepId,
        sessionId,
        projectId,
        image: uint8ArrayToBlob(screenshotPersistedBytes, screenshotPersistedMime),
        format,
        widthPx,
        heightPx,
        sizeBytes: screenshotPersistedBytes.length,
        createdAt: now
      };
    } else if (stepLike.screenshotDataUrl && stepLike.screenshotDataUrl.length > 32) {
      const { bytes, mime } = dataUrlToUint8AndMime(stepLike.screenshotDataUrl);
      screenshotPersistedBytes = bytes;
      screenshotPersistedMime = mime;
      const id = uuidv4();
      const finalFormat = stepLike.screenshotFormat === "image/png" ? "image/png" : detectImageMimeOrDefault(mime);
      const hasDims = stepLike.screenshotWidthPx && stepLike.screenshotHeightPx;
      const dims = hasDims ? { widthPx: stepLike.screenshotWidthPx, heightPx: stepLike.screenshotHeightPx } : screenshotPersistedBytes.length ? { widthPx: 2, heightPx: 2 } : { widthPx: 0, heightPx: 0 };
      screenshot = {
        screenshotId: id,
        stepId: step.stepId,
        sessionId,
        projectId,
        image: uint8ArrayToBlob(screenshotPersistedBytes, screenshotPersistedMime),
        format: finalFormat,
        widthPx: dims.widthPx,
        heightPx: dims.heightPx,
        sizeBytes: screenshotPersistedBytes.length,
        createdAt: now
      };
      step.screenshotId = id;
    }
    const stores = [STORE.STEPS];
    if (screenshot) stores.push(STORE.SCREENSHOTS, STORE.SESSIONS);
    let persistedShot = null;
    if (screenshot && screenshotPersistedBytes) {
      persistedShot = {
        screenshotId: screenshot.screenshotId,
        stepId: screenshot.stepId,
        sessionId: screenshot.sessionId,
        projectId: screenshot.projectId,
        imageBytes: screenshotPersistedBytes,
        imageMime: screenshotPersistedMime,
        format: screenshot.format,
        widthPx: screenshot.widthPx,
        heightPx: screenshot.heightPx,
        sizeBytes: screenshotPersistedBytes.length,
        createdAt: screenshot.createdAt
      };
    }
    await withTransaction(stores, "readwrite", async (tx) => {
      const stepsStore = tx.objectStore(STORE.STEPS);
      await wrapRequest(stepsStore.put(step));
      if (persistedShot) {
        const shotsStore = tx.objectStore(STORE.SCREENSHOTS);
        await wrapRequest(shotsStore.put(persistedShot));
      }
    });
    endSave();
    return { step, screenshot };
  } catch (e) {
    endSave(e instanceof Error ? e.message : String(e));
    throw friendlyStorageError(e, "gravar passo com screenshot");
  }
}
async function listStepsBySession(sessionId) {
  try {
    await openDatabase();
    return await withTransaction(STORE.STEPS, "readonly", (tx) => {
      return new Promise((resolve, reject) => {
        const idx = tx.objectStore(STORE.STEPS).index(INDEX.STEPS_BY_SESSION);
        const range = getKeyRange().lowerBound([sessionId]);
        const cursorReq = idx.openCursor(range, "next");
        const out = [];
        cursorReq.onsuccess = () => {
          const cursor = cursorReq.result;
          if (!cursor) return resolve(out);
          const val = cursor.value;
          if (val.sessionId !== sessionId) return resolve(out);
          out.push(val);
          cursor.continue();
        };
        cursorReq.onerror = () => reject(cursorReq.error ?? new Error("cursor falhou"));
      });
    });
  } catch (e) {
    throw friendlyStorageError(e, "listar passos");
  }
}
async function getScreenshotById(screenshotId) {
  try {
    await openDatabase();
    return await withTransaction(
      STORE.SCREENSHOTS,
      "readonly",
      (tx) => wrapRequest(
        tx.objectStore(STORE.SCREENSHOTS).get(screenshotId)
      ).then((v) => v ? screenshotFromPersisted(v) : null)
    );
  } catch (e) {
    throw friendlyStorageError(e, "ler screenshot");
  }
}
async function getSetting(key) {
  try {
    await openDatabase();
    const r = await withTransaction(
      STORE.SETTINGS,
      "readonly",
      (tx) => wrapRequest(tx.objectStore(STORE.SETTINGS).get(key)).then(
        (v) => v ?? null
      )
    );
    return r?.value ?? null;
  } catch (e) {
    throw friendlyStorageError(e, `ler setting ${key}`);
  }
}
async function setSetting(key, value) {
  beginSave();
  try {
    await openDatabase();
    const entry = { key, value, updatedAt: Date.now() };
    await withTransaction(
      STORE.SETTINGS,
      "readwrite",
      (tx) => wrapRequest(tx.objectStore(STORE.SETTINGS).put(entry))
    );
    endSave();
  } catch (e) {
    endSave(e instanceof Error ? e.message : String(e));
    throw friendlyStorageError(e, `gravar setting ${key}`);
  }
}
async function deleteStepCascade(stepId) {
  beginSave();
  try {
    await openDatabase();
    await withTransaction([STORE.STEPS, STORE.SCREENSHOTS], "readwrite", async (tx) => {
      const shots = tx.objectStore(STORE.SCREENSHOTS);
      const shot = await wrapRequest(
        shots.index(INDEX.SCREENSHOTS_BY_STEP).get([stepId])
      );
      if (shot) await wrapRequest(shots.delete(shot.screenshotId));
      await wrapRequest(tx.objectStore(STORE.STEPS).delete(stepId));
    });
    endSave();
  } catch (e) {
    endSave(e instanceof Error ? e.message : String(e));
    throw friendlyStorageError(e, `excluir passo ${stepId}`);
  }
}
async function clearSessionSteps(sessionId) {
  const steps = await listStepsBySession(sessionId);
  for (const step of steps) await deleteStepCascade(step.stepId);
  return steps.length;
}
async function moveSessionEvidenceToProject(sessionId, projectId) {
  await openDatabase();
  const steps = await listStepsBySession(sessionId);
  let screenshots = 0;
  await withTransaction([STORE.STEPS, STORE.SCREENSHOTS], "readwrite", async (tx) => {
    const stepStore = tx.objectStore(STORE.STEPS);
    for (const step of steps) {
      await wrapRequest(stepStore.put({ ...step, projectId }));
    }
    const shotIndex = tx.objectStore(STORE.SCREENSHOTS).index("by_sessionId");
    await new Promise((resolve, reject) => {
      const cursorRequest = shotIndex.openCursor(getKeyRange().only(sessionId));
      cursorRequest.onsuccess = () => {
        const cursor = cursorRequest.result;
        if (!cursor) return resolve();
        cursor.update({ ...cursor.value, projectId });
        screenshots += 1;
        cursor.continue();
      };
      cursorRequest.onerror = () => reject(cursorRequest.error ?? new Error("cursor de screenshots falhou"));
    });
  });
  return { steps: steps.length, screenshots };
}
async function migrateFromLegacyChromeStorage(opts = {}) {
  beginSave();
  const result = {
    ok: true,
    migratedProjects: 0,
    migratedSessions: 0,
    migratedSteps: 0,
    migratedScreenshots: 0,
    skippedLegacyEmpty: true,
    errors: []
  };
  const getter = opts.getLegacy ?? (async (k) => {
    if (typeof chrome === "undefined" || !chrome.storage?.local?.get) return void 0;
    const r = await chrome.storage.local.get(k);
    return r?.[k];
  });
  try {
    const [rawRec, rawSteps] = await Promise.all([
      getter(STORAGE_KEY_RECORDING),
      getter(STORAGE_KEY_STEPS)
    ]);
    const rec = rawRec && typeof rawRec === "object" ? rawRec : null;
    const steps = Array.isArray(rawSteps) ? rawSteps : [];
    if (!rec && steps.length === 0) {
      result.skippedLegacyEmpty = true;
      await setSetting("migration.v1.completedAt", Date.now());
      result.completedAt = Date.now();
      endSave();
      return result;
    }
    result.skippedLegacyEmpty = false;
    const projectName = opts.defaultProjectName ?? "Projeto (migrado do legado)";
    const project = await createProject({ name: projectName });
    result.migratedProjects = 1;
    const sessionName = opts.defaultSessionName ?? (rec?.sessionId ? `Sessão ${String(rec.sessionId).slice(0, 8)}` : "Sessão migrada");
    const rsLike = {
      sessionId: rec?.sessionId ?? uuidv4(),
      state: rec?.state ?? "finalized",
      tabId: rec?.tabId ?? null,
      stepCount: Number(rec?.stepCount ?? steps.length),
      startedAt: typeof rec?.startedAt === "number" ? rec.startedAt : null,
      endedAt: typeof rec?.endedAt === "number" ? rec.endedAt : null,
      durationMs: Number(rec?.durationMs ?? 0)
    };
    const session = await upsertSessionFromRecordingSession(project.projectId, rsLike, {
      name: sessionName,
      description: "Sessão migrada do armazenamento legado (localStorage/chrome.storage.local)"
    });
    result.migratedSessions = 1;
    for (const raw of steps) {
      try {
        const valid = validateRecordingStepLegacy(raw);
        if (!valid) continue;
        const { step, screenshot } = await addStepWithScreenshot(
          project.projectId,
          session.sessionId,
          valid,
          null
        );
        if (screenshot) result.migratedScreenshots += 1;
        result.migratedSteps += 1;
      } catch (e) {
        result.errors.push(`step_migrate: ${e instanceof Error ? e.message : String(e)}`);
      }
    }
    const updatedSession = { ...session, stepCount: result.migratedSteps };
    await withTransaction(
      STORE.SESSIONS,
      "readwrite",
      (tx) => wrapRequest(tx.objectStore(STORE.SESSIONS).put(updatedSession))
    );
    result.completedAt = Date.now();
    await setSetting("migration.v1.completedAt", result.completedAt);
    if (opts.removeLegacyAfter && typeof chrome !== "undefined" && chrome.storage?.local?.remove) {
      try {
        await chrome.storage.local.remove([STORAGE_KEY_STEPS, STORAGE_KEY_LAST_STEP]);
      } catch (e) {
        result.errors.push(
          `remove_legado_apos_migracao: ${e instanceof Error ? e.message : String(e)}`
        );
      }
    }
    if (result.errors.length > 0) result.ok = false;
    endSave();
    return result;
  } catch (e) {
    endSave(e instanceof Error ? e.message : String(e));
    result.ok = false;
    result.errors.push(`top_level: ${e instanceof Error ? e.message : String(e)}`);
    return result;
  }
}
function validateRecordingStepLegacy(raw) {
  if (!raw || typeof raw !== "object") return null;
  if (!("stepId" in raw) || typeof raw.stepId !== "string") return null;
  return raw;
}
async function exportBackup(opts = {}) {
  try {
    await openDatabase();
    const projects = opts.projectIds?.length ? (await Promise.all(opts.projectIds.map((id) => getProjectById(id)))).filter(
      (p) => !!p
    ) : await listProjects({ includeArchived: true });
    const projectIdSet = new Set(projects.map((p) => p.projectId));
    const allSessions = [];
    const allSteps = [];
    const allShotsMeta = [];
    const settings = await withTransaction(
      STORE.SETTINGS,
      "readonly",
      (tx) => {
        return new Promise((resolve, reject) => {
          const cur = tx.objectStore(STORE.SETTINGS).openCursor();
          const out = [];
          cur.onsuccess = () => {
            const cursor = cur.result;
            if (!cursor) return resolve(out);
            out.push(cursor.value);
            cursor.continue();
          };
          cur.onerror = () => reject(cur.error ?? new Error("settings cursor falhou"));
        });
      }
    );
    for (const p of projects) {
      const ss = await listSessionsByProject(p.projectId);
      for (const s of ss) {
        allSessions.push(s);
        const steps = await listStepsBySession(s.sessionId);
        for (const step of steps) {
          if (!projectIdSet.has(step.projectId)) continue;
          allSteps.push(step);
          if (step.screenshotId && (opts.includeScreenshots ?? true)) {
            const shot = await getScreenshotById(step.screenshotId);
            if (shot) {
              const dataUrl = await blobToDataUrl(shot.image);
              allShotsMeta.push({
                screenshotId: shot.screenshotId,
                stepId: shot.stepId,
                sessionId: shot.sessionId,
                projectId: shot.projectId,
                imageDataUrl: dataUrl,
                format: shot.format,
                widthPx: shot.widthPx,
                heightPx: shot.heightPx,
                sizeBytes: shot.sizeBytes,
                createdAt: shot.createdAt
              });
            }
          }
        }
      }
    }
    return {
      schema: "homolog-backup",
      schemaVersion: 1,
      exportedAt: Date.now(),
      projects,
      sessions: allSessions,
      steps: allSteps,
      screenshotsMeta: allShotsMeta,
      settings
    };
  } catch (e) {
    throw friendlyStorageError(e, "exportar backup");
  }
}

// src/background/index.ts
var logger = {
  info: (...args) => console.log("[homolog:bg]", ...args),
  warn: (...args) => console.warn("[homolog:bg]", ...args),
  error: (...args) => console.error("[homolog:bg]", ...args)
};
var screenshotQueue = Promise.resolve();
var lastCaptureStartedAt = 0;
function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, Math.max(0, ms)));
}
function enqueueScreenshot(operation) {
  const result = screenshotQueue.then(operation, operation);
  screenshotQueue = result.then(() => void 0, () => void 0);
  return result;
}
function setActionBadge(state) {
  if (!chrome.action) return;
  let text = "";
  let color = "#64748b";
  switch (state.state) {
    case "recording":
      text = `${state.stepCount}`;
      color = "#dc2626";
      break;
    case "paused":
      text = "II";
      color = "#d97706";
      break;
    case "finalized":
      text = "OK";
      color = "#2563eb";
      break;
    case "idle":
    default:
      text = "";
      color = "#64748b";
      break;
  }
  try {
    chrome.action.setBadgeBackgroundColor({ color });
    chrome.action.setBadgeText({ text });
  } catch (e) {
    logger.warn("setBadge falhou", e);
  }
}
async function loadSession() {
  try {
    const raw = await chrome.storage.local.get(STORAGE_KEY_RECORDING);
    const parsed = raw?.[STORAGE_KEY_RECORDING];
    if (parsed && typeof parsed === "object" && "sessionId" in parsed) {
      return {
        ...createEmptySession(),
        ...parsed
      };
    }
  } catch (e) {
    logger.warn("loadSession falhou; usando default", e);
  }
  return createNewSession();
}
async function saveSession(session) {
  try {
    await chrome.storage.local.set({ [STORAGE_KEY_RECORDING]: session });
    setActionBadge(session);
    logger.info("sessao salva", {
      id: session.sessionId.slice(0, 8),
      state: session.state,
      stepCount: session.stepCount
    });
  } catch (e) {
    logger.warn("saveSession falhou", e);
  }
}
async function loadLastInteraction() {
  try {
    const raw = await chrome.storage.local.get(STORAGE_KEY_LAST_INTERACTION);
    const parsed = raw?.[STORAGE_KEY_LAST_INTERACTION];
    if (!parsed) return null;
    const valid = validateInteractionEvent(parsed);
    return valid.ok ? valid.value : null;
  } catch {
    return null;
  }
}
async function saveLastInteraction(interaction) {
  try {
    if (interaction === null) {
      await chrome.storage.local.remove(STORAGE_KEY_LAST_INTERACTION);
      return;
    }
    await chrome.storage.local.set({ [STORAGE_KEY_LAST_INTERACTION]: interaction });
  } catch (e) {
    logger.warn("saveLastInteraction falhou", e);
  }
}
async function loadSteps(sessionId) {
  try {
    const raw = await chrome.storage.local.get(STORAGE_KEY_STEPS);
    const arr = raw?.[STORAGE_KEY_STEPS];
    if (!Array.isArray(arr)) return [];
    const out = [];
    for (const item of arr) {
      const v = validateRecordingStep(item);
      if (!v.ok) continue;
      if (sessionId && v.value.sessionId !== sessionId) continue;
      out.push(v.value);
    }
    out.sort((a, b) => a.sequence - b.sequence);
    return out;
  } catch {
    return [];
  }
}
async function saveSteps(steps) {
  try {
    const max = SCREENSHOT.MAX_STEPS_IN_STORAGE;
    const slice = steps.length > max ? steps.slice(steps.length - max) : steps;
    await chrome.storage.local.set({ [STORAGE_KEY_STEPS]: slice });
  } catch (e) {
    logger.warn("saveSteps falhou (storage pode estar cheio)", e);
  }
}
async function clearStepsForNewSession() {
  try {
    await chrome.storage.local.remove([STORAGE_KEY_STEPS, STORAGE_KEY_LAST_STEP]);
  } catch {
  }
}
async function loadLastStep() {
  try {
    const raw = await chrome.storage.local.get(STORAGE_KEY_LAST_STEP);
    const parsed = raw?.[STORAGE_KEY_LAST_STEP];
    const v = validateRecordingStep(parsed);
    return v.ok ? v.value : null;
  } catch {
    return null;
  }
}
async function saveLastStep(step) {
  try {
    if (step === null) {
      await chrome.storage.local.remove(STORAGE_KEY_LAST_STEP);
      return;
    }
    await chrome.storage.local.set({ [STORAGE_KEY_LAST_STEP]: step });
  } catch (e) {
    logger.warn("saveLastStep falhou", e);
  }
}
async function broadcastState(session) {
  try {
    await chrome.runtime.sendMessage({
      type: "__STATE_CHANGED__",
      payload: { session }
    });
  } catch {
  }
}
async function broadcastInteractionRecorded(interaction, session) {
  try {
    await chrome.runtime.sendMessage({
      type: "__INTERACTION_RECORDED__",
      payload: { interaction, session }
    });
  } catch {
  }
}
async function broadcastStepRecorded(step, session) {
  try {
    await chrome.runtime.sendMessage({
      type: "__STEP_RECORDED__",
      payload: { step, session }
    });
  } catch {
  }
}
async function getActiveTabId() {
  try {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });
    return tab?.id ?? null;
  } catch {
    return null;
  }
}
async function onGetState() {
  const [s, last] = await Promise.all([loadSession(), loadLastInteraction()]);
  return { ok: true, state: s, lastInteraction: last ?? void 0 };
}
async function onGetLastInteraction() {
  const [s, last] = await Promise.all([loadSession(), loadLastInteraction()]);
  return { ok: true, state: s, lastInteraction: last ?? void 0 };
}
function onGetMyTabId(sender) {
  const tabId = sender?.tab?.id ?? null;
  if (tabId === null || tabId === void 0) {
    return { ok: false, error: "sender sem tab.id" };
  }
  return { ok: true, tabId };
}
async function onGetLastStep() {
  const [s, lastStep, lastInter] = await Promise.all([
    loadSession(),
    loadLastStep(),
    loadLastInteraction()
  ]);
  return {
    ok: true,
    state: s,
    lastInteraction: lastInter ?? void 0,
    lastStep: lastStep ?? void 0
  };
}
async function onListSteps() {
  const [s, steps] = await Promise.all([loadSession(), loadSteps()]);
  return { ok: true, state: s, steps };
}
async function ensureContentInjected(tabId) {
  if (typeof tabId !== "number") return false;
  try {
    if (!chrome.scripting || typeof chrome.scripting.executeScript !== "function") return false;
    let tabUrl;
    try {
      const tab = await chrome.tabs.get(tabId);
      tabUrl = tab.url;
      if (!tabUrl) return false;
      if (!/^https?:\/\//i.test(tabUrl) && !/^file:\/\//i.test(tabUrl)) {
        logger.warn(
          `ensureContentInjected: pulando tab#${tabId} (url nao suportada: ${tabUrl.slice(0, 120)})`
        );
        return false;
      }
    } catch {
    }
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content/index.js"]
    });
    logger.info(
      `ensureContentInjected: content script injetado na aba #${tabId} (${(tabUrl ?? "").slice(0, 120)})`
    );
    return true;
  } catch (e) {
    logger.warn(
      `ensureContentInjected falhou tab#${tabId} —`,
      e instanceof Error ? e.message : String(e)
    );
    return false;
  }
}
async function getOrCreateActiveProjectId() {
  try {
    if (typeof chrome?.storage?.local?.get === "function") {
      const stored = await chrome.storage.local.get(STORAGE_KEY_ACTIVE_PROJECT_ID);
      const existing = stored?.[STORAGE_KEY_ACTIVE_PROJECT_ID];
      if (typeof existing === "string" && existing.length > 0) {
        const project = await getProjectById(existing);
        if (project) return existing;
      }
    }
    const list = await listProjects({ includeArchived: false, limit: 1 });
    if (list.length > 0) {
      if (typeof chrome?.storage?.local?.set === "function") {
        await chrome.storage.local.set({ [STORAGE_KEY_ACTIVE_PROJECT_ID]: list[0].projectId });
      }
      return list[0].projectId;
    }
    const proj = await createProject({ name: "Projeto padrão", description: "Criado automaticamente pela extensão Homolog" });
    if (typeof chrome?.storage?.local?.set === "function") {
      await chrome.storage.local.set({ [STORAGE_KEY_ACTIVE_PROJECT_ID]: proj.projectId });
    }
    return proj.projectId;
  } catch (e) {
    logger.warn("getOrCreateActiveProjectId falhou; usando sessionId temporario como fallback", e);
    return "default-project-fallback";
  }
}
async function persistRecordingSessionOnIdb(session, opts) {
  try {
    const projectId = opts?.projectId ?? await getOrCreateActiveProjectId();
    const sess = await upsertSessionFromRecordingSession(projectId, session, {
      name: opts?.name,
      description: opts?.description
    });
    if (typeof chrome?.storage?.local?.set === "function") {
      await chrome.storage.local.set({
        [STORAGE_KEY_ACTIVE_PROJECT_ID]: projectId,
        [STORAGE_KEY_ACTIVE_SESSION_ID]: sess.sessionId
      });
    }
    return sess;
  } catch (e) {
    logger.warn("persistRecordingSessionOnIdb ignorou erro:", e instanceof Error ? e.message : String(e));
    return null;
  }
}
async function reconcileSessionEvidence(session, projectId) {
  const recoverySteps = await loadSteps(session.sessionId);
  if (recoverySteps.length === 0) return 0;
  const persistedSteps = await listStepsBySession(session.sessionId);
  const persistedById = new Map(persistedSteps.map((step) => [step.stepId, step]));
  let repaired = 0;
  for (const step of recoverySteps) {
    const persisted = persistedById.get(step.stepId);
    const screenshot = persisted?.screenshotId ? await getScreenshotById(persisted.screenshotId) : null;
    if (persisted && screenshot?.image.size) continue;
    await addStepWithScreenshot(projectId, session.sessionId, step, null);
    repaired += 1;
  }
  if (repaired > 0) {
    logger.info(`reconcileSessionEvidence: ${repaired} passo(s) recuperado(s)`);
  }
  return repaired;
}
async function onStart() {
  const current = await loadSession();
  const tabId = await getActiveTabId();
  let session = current;
  if (session.state === "idle") {
    const fresh = reset(session, tabId).session;
    const r = applyTransition(fresh, "START");
    session = r.session;
  } else if (session.state === "finalized") {
    const fresh = createNewSession(tabId);
    const r = applyTransition(fresh, "START");
    session = r.session;
  } else {
    const r = applyTransition(session, "START");
    session = r.session;
  }
  session.tabId = session.tabId ?? tabId;
  let targetUrl = "";
  try {
    if (session.tabId !== null && session.tabId !== void 0) {
      const t = await chrome.tabs.get(session.tabId);
      targetUrl = t.url ?? "";
    }
  } catch {
  }
  logger.info(
    `onStart: sessao pronta tab#${session.tabId} url=${targetUrl.slice(0, 160)} state=${session.state}`
  );
  await clearStepsForNewSession();
  await saveLastInteraction(null);
  await saveSession(session);
  void persistRecordingSessionOnIdb(session, {
    name: `Sessão ${new Date(session.startedAt ?? Date.now()).toLocaleString("pt-BR")}`,
    description: targetUrl ? `Origem: ${targetUrl.slice(0, 200)}` : null
  });
  if (session.tabId !== null && session.tabId !== void 0) {
    await ensureContentInjected(session.tabId);
  }
  await broadcastState(session);
  return { ok: true, state: session };
}
async function onSimpleTransition(t) {
  if (t === "FINALIZE") {
    await screenshotQueue;
  }
  const current = await loadSession();
  const r = applyTransition(current, t);
  if (!r.changed) {
    return { ok: false, state: r.session, error: r.reason };
  }
  if (t !== "INCREMENT_STEP") {
    if (t === "FINALIZE") {
      const activeProjectId = await getOrCreateActiveProjectId();
      await persistRecordingSessionOnIdb(r.session, { projectId: activeProjectId });
      await reconcileSessionEvidence(r.session, activeProjectId);
      await moveSessionEvidenceToProject(r.session.sessionId, activeProjectId);
      await persistRecordingSessionOnIdb(r.session, { projectId: activeProjectId });
    } else {
      await persistRecordingSessionOnIdb(r.session);
    }
  }
  await saveSession(r.session);
  await broadcastState(r.session);
  if (t === "FINALIZE") {
    try {
      await openPanelTab(true);
    } catch (error) {
      logger.warn("gravação finalizada, mas o painel não pôde ser aberto", error);
    }
  }
  return { ok: true, state: r.session };
}
async function onReset() {
  const current = await loadSession();
  const tabId = await getActiveTabId();
  const r = reset(current, tabId);
  await clearStepsForNewSession();
  await saveLastInteraction(null);
  await saveSession(r.session);
  void persistRecordingSessionOnIdb(r.session, {
    name: `Sessão ${new Date(r.session.startedAt ?? Date.now()).toLocaleString("pt-BR")}`,
    description: "Sessão limpa (reset)"
  });
  await broadcastState(r.session);
  return { ok: true, state: r.session };
}
async function onInstalled() {
  logger.info("instalado/atualizado");
  try {
    const done = await getSetting("migration.v1.completedAt").catch(() => null);
    if (!done) {
      const m = await migrateFromLegacyChromeStorage({ removeLegacyAfter: false });
      logger.info(
        `migracao legado concluida ok=${m.ok} steps=${m.migratedSteps} shots=${m.migratedScreenshots} erros=${m.errors.length}`
      );
    } else {
      logger.info(`migracao legado ja concluida em ${new Date(done).toISOString()}`);
    }
    try {
      if (typeof chrome?.storage?.local?.set === "function") {
        await chrome.storage.local.set({
          [STORAGE_KEY_IDB_MIGRATION_DONE]: Date.now()
        });
      }
    } catch {
    }
  } catch (e) {
    logger.warn("migracao idb falhou; prosseguindo sem ela", e);
  }
  const s = await loadSession();
  if (!s.sessionId) {
    const fresh = createNewSession();
    await saveSession(fresh);
  } else {
    setActionBadge(s);
  }
  try {
    subscribeSaveIndicator((snap) => {
      logger.info(
        `save indicator status=${snap.status} pending=${snap.pendingCount} lastSavedAt=${snap.lastSavedAt ? new Date(snap.lastSavedAt).toISOString() : "null"}${snap.lastError ? ` erro=${snap.lastError.slice(0, 160)}` : ""}`
      );
    });
  } catch {
  }
}
async function captureTabDataUrl(tabIdArg) {
  const tabId = typeof tabIdArg === "number" ? tabIdArg : null;
  if (tabId === null) throw new Error("nao foi possivel identificar a aba da sessao");
  const tab = await chrome.tabs.get(tabId);
  if (typeof tab.windowId !== "number") throw new Error("nao foi possivel identificar a janela da aba");
  if (!tab.active) throw new Error("a aba da gravacao nao esta ativa");
  const captureOptions = {
    format: "jpeg",
    quality: Math.max(1, Math.min(100, Math.round(SCREENSHOT.QUALITY * 100)))
  };
  try {
    const remaining = SCREENSHOT.MIN_INTERVAL_BETWEEN_CAPTURES_MS - (Date.now() - lastCaptureStartedAt);
    if (remaining > 0) await wait(remaining);
    lastCaptureStartedAt = Date.now();
    let dataUrl = "";
    let lastError = null;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      try {
        dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, captureOptions);
        lastError = null;
        break;
      } catch (error) {
        lastError = error;
        if (attempt < 2) await wait(SCREENSHOT.MIN_INTERVAL_BETWEEN_CAPTURES_MS);
      }
    }
    if (lastError) throw lastError;
    if (typeof dataUrl !== "string" || !dataUrl.startsWith("data:image/")) {
      throw new Error("o navegador retornou uma captura invalida");
    }
    return { dataUrl: typeof dataUrl === "string" ? dataUrl : "", tabId };
  } catch (e) {
    throw new Error(
      e instanceof Error ? `captura falhou: ${e.message}` : "captura falhou (erro desconhecido)"
    );
  }
}
async function ensureSameTabAsSession(sender, session) {
  const senderTabId = sender?.tab?.id ?? null;
  if (session.tabId === null || senderTabId === null) {
    return { ok: true, senderTabId };
  }
  if (senderTabId !== session.tabId) {
    return {
      ok: false,
      error: `aba enviou interacao diferente da aba gravada (sender=${senderTabId} vs sessao=${session.tabId})`,
      senderTabId
    };
  }
  try {
    const tab = await chrome.tabs.get(session.tabId);
    if (!tab) {
      return {
        ok: false,
        error: "aba original da sessao nao existe mais",
        senderTabId
      };
    }
  } catch (e) {
    return {
      ok: false,
      error: `verificacao de aba falhou: ${e instanceof Error ? e.message : String(e)}`,
      senderTabId
    };
  }
  return { ok: true, senderTabId };
}
function isDuplicateInteractionStep(steps, interactionId, windowMs = 1500, timestampNow = Date.now()) {
  for (let i = steps.length - 1; i >= 0; i -= 1) {
    const s = steps[i];
    if (timestampNow - s.timestamp > windowMs) break;
    if (s.interactionId === interactionId) return true;
  }
  return false;
}
async function onRequestScreenshot(payload, sender) {
  const session = await loadSession();
  if (session.state !== "recording") {
    return { ok: false, state: session, error: "sessao nao esta gravando" };
  }
  const interactionRaw = payload?.interaction;
  const valid = validateInteractionEvent(interactionRaw);
  if (!valid.ok) {
    return { ok: false, error: `interacao invalida: ${valid.error}` };
  }
  const ev = valid.value;
  const tabCheck = await ensureSameTabAsSession(sender, session);
  if (!tabCheck.ok) {
    return { ok: false, error: tabCheck.error ?? "troca de aba detectada" };
  }
  if (ev.sessionId && ev.sessionId !== session.sessionId) {
    logger.warn(
      "interacao de outra sessao recebida (esperado=%s recebido=%s)",
      session.sessionId.slice(0, 8),
      ev.sessionId.slice(0, 8)
    );
  }
  const priorSteps = await loadSteps(session.sessionId);
  if (isDuplicateInteractionStep(priorSteps, ev.interactionId, 1500, Date.now())) {
    return { ok: false, error: "step duplicado para mesma interacao; ignorado" };
  }
  let captured;
  try {
    captured = await captureTabDataUrl(session.tabId ?? tabCheck.senderTabId);
  } catch (e) {
    return {
      ok: false,
      error: e instanceof Error ? e.message : "screenshot indisponivel nesta pagina"
    };
  }
  if (!captured.dataUrl || captured.dataUrl.length < 32) {
    return { ok: false, error: "screenshot vazia; navegador bloqueou a captura" };
  }
  const compressed = await compressScreenshotDataUrl(captured.dataUrl, {
    maxWidthPx: SCREENSHOT.MAX_WIDTH_PX,
    format: SCREENSHOT.FORMAT,
    quality: SCREENSHOT.QUALITY
  });
  if (!compressed) {
    return { ok: false, error: "screenshot corrompida apos compressao" };
  }
  const nextSequence = priorSteps.length + 1;
  const step = buildRecordingStep({
    interaction: ev,
    screenshotDataUrl: captured.dataUrl,
    sequence: nextSequence,
    tabId: session.tabId ?? tabCheck.senderTabId,
    sessionId: session.sessionId,
    compressed
  });
  if (!step) {
    return { ok: false, error: "falha ao montar step apos screenshot" };
  }
  const stepValid = validateRecordingStep(step);
  if (!stepValid.ok) {
    return { ok: false, error: `step invalido: ${stepValid.error}` };
  }
  const stepR = applyTransition(session, "INCREMENT_STEP");
  let finalSession;
  if (!stepR.changed) {
    logger.warn("INCREMENT_STEP nao aplicavel ao salvar screenshot", stepR.reason);
    finalSession = session;
  } else {
    await saveSession(stepR.session);
    finalSession = stepR.session;
  }
  const nextSteps = [...priorSteps, stepValid.value];
  await saveSteps(nextSteps);
  await saveLastStep(stepValid.value);
  await saveLastInteraction(ev);
  try {
    const projectId = await getOrCreateActiveProjectId();
    const persisted = await addStepWithScreenshot(
      projectId,
      finalSession.sessionId,
      stepValid.value,
      null
    );
    const sessOnIdb = await getSessionById(finalSession.sessionId);
    if (!sessOnIdb || sessOnIdb.stepCount !== stepValid.value.sequence) {
      const updated = {
        ...finalSession,
        stepCount: stepValid.value.sequence
      };
      await upsertSessionFromRecordingSession(projectId, updated);
    }
  } catch (e) {
    logger.warn(
      `idb persist step falhou (mantendo legado) sequence=${stepValid.value.sequence} erro:`,
      e instanceof Error ? e.message : String(e)
    );
  }
  await broadcastState(finalSession);
  await broadcastStepRecorded(stepValid.value, finalSession);
  return { ok: true, state: finalSession, lastStep: stepValid.value, lastInteraction: ev };
}
async function onDeleteStep(payload) {
  const stepId = typeof payload?.stepId === "string" ? payload.stepId : "";
  if (!stepId || stepId.length > 128) return { ok: false, error: "passo inválido" };
  const session = await loadSession();
  const steps = await loadSteps(session.sessionId);
  if (!steps.some((step) => step.stepId === stepId)) {
    return { ok: false, state: session, error: "passo não encontrado" };
  }
  const remaining = steps.filter((step) => step.stepId !== stepId).map((step, index) => ({ ...step, sequence: index + 1 }));
  await deleteStepCascade(stepId);
  await saveSteps(remaining);
  await saveLastStep(remaining.at(-1) ?? null);
  const updated = { ...session, stepCount: remaining.length, lastUpdatedAt: Date.now() };
  await saveSession(updated);
  await upsertSessionFromRecordingSession(await getOrCreateActiveProjectId(), updated);
  await broadcastState(updated);
  return { ok: true, state: updated, steps: remaining };
}
async function onClearSteps() {
  const session = await loadSession();
  await clearSessionSteps(session.sessionId);
  await chrome.storage.local.remove([
    STORAGE_KEY_STEPS,
    STORAGE_KEY_LAST_STEP,
    STORAGE_KEY_LAST_INTERACTION
  ]);
  const updated = { ...session, stepCount: 0, lastUpdatedAt: Date.now() };
  await saveSession(updated);
  await upsertSessionFromRecordingSession(await getOrCreateActiveProjectId(), updated);
  await broadcastState(updated);
  return { ok: true, state: updated, steps: [] };
}
async function onGetProjectContext() {
  const project = await getProjectById(await getOrCreateActiveProjectId());
  return {
    ok: true,
    projectContext: {
      name: project?.name ?? "Projeto padrão",
      functionality: String(project?.metadata?.feature ?? ""),
      locked: project?.metadata?.contextLocked === true
    }
  };
}
async function onSaveProjectContext(payload) {
  const name = typeof payload?.name === "string" ? payload.name.trim().slice(0, 200) : "";
  const functionality = typeof payload?.functionality === "string" ? payload.functionality.trim().slice(0, 300) : "";
  if (!name) return { ok: false, error: "Informe o nome do projeto." };
  const projectId = await getOrCreateActiveProjectId();
  const current = await getProjectById(projectId);
  const updated = await updateProject(projectId, {
    name,
    metadata: {
      ...current?.metadata ?? {},
      feature: functionality,
      environment: "Web",
      contextLocked: true
    }
  });
  return {
    ok: true,
    projectContext: { name: updated.name, functionality, locked: true }
  };
}
async function onNewProjectContext() {
  const current = await loadSession();
  let archived = current;
  if (current.state === "recording" || current.state === "paused") {
    const finalized = applyTransition(current, "FINALIZE");
    archived = finalized.session;
    await saveSession(archived);
    await persistRecordingSessionOnIdb(archived);
  }
  const project = await createProject({
    name: "Novo projeto",
    description: "Criado pelo menu lateral do Homolog",
    metadata: { feature: "", environment: "Web", contextLocked: false }
  });
  await chrome.storage.local.set({ [STORAGE_KEY_ACTIVE_PROJECT_ID]: project.projectId });
  const nextSession = createNewSession(current.tabId);
  await clearStepsForNewSession();
  await saveLastInteraction(null);
  await saveSession(nextSession);
  await upsertSessionFromRecordingSession(project.projectId, nextSession);
  await broadcastState(nextSession);
  const panelUrl = new URL("http://localhost:5173/");
  panelUrl.searchParams.set("homologExtensionId", chrome.runtime.id);
  try {
    await chrome.tabs.create({ url: panelUrl.toString(), active: false });
  } catch (error) {
    logger.warn("não foi possível abrir o painel em segundo plano", error);
  }
  return {
    ok: true,
    state: nextSession,
    steps: [],
    projectContext: { name: project.name, functionality: "", locked: false }
  };
}
async function onOpenPanelBackground() {
  await openPanelTab(false);
  return { ok: true };
}
async function openPanelTab(active) {
  const panelUrl = new URL("http://localhost:5173/");
  panelUrl.searchParams.set("homologExtensionId", chrome.runtime.id);
  await chrome.tabs.create({ url: panelUrl.toString(), active });
}
async function onRecordInteraction(payload, sender) {
  const session = await loadSession();
  if (session.state !== "recording") {
    return { ok: false, state: session, error: "sessao nao esta gravando" };
  }
  const interactionRaw = payload?.interaction;
  const valid = validateInteractionEvent(interactionRaw);
  if (!valid.ok) {
    return { ok: false, error: `interacao invalida: ${valid.error}` };
  }
  const ev = valid.value;
  if (ev.sessionId && ev.sessionId !== session.sessionId) {
    logger.warn(
      "interacao de outra sessao recebida (esperado=%s recebido=%s); aceitando",
      session.sessionId.slice(0, 8),
      ev.sessionId.slice(0, 8)
    );
  }
  if (sender?.tab?.id !== void 0 && session.tabId !== null) {
    if (sender.tab.id !== session.tabId) {
      return {
        ok: false,
        error: `aba enviou interacao diferente da aba original (senderTab ${sender.tab.id} vs sessionTab ${session.tabId})`
      };
    }
  }
  const stepR = applyTransition(session, "INCREMENT_STEP");
  let currentFinal;
  if (!stepR.changed) {
    logger.warn("INCREMENT_STEP nao aplicavel no bg", stepR.reason);
    currentFinal = session;
  } else {
    await saveSession(stepR.session);
    currentFinal = stepR.session;
  }
  await saveLastInteraction(ev);
  await broadcastState(currentFinal);
  await broadcastInteractionRecorded(ev, currentFinal);
  return { ok: true, state: currentFinal, lastInteraction: ev };
}
if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onInstalled) {
  chrome.runtime.onInstalled.addListener(() => {
    void onInstalled();
  });
  chrome.runtime.onStartup.addListener(() => {
    void (async () => {
      const s = await loadSession();
      setActionBadge(s);
    })();
  });
  try {
    chrome.tabs.onUpdated.addListener((tabId, info) => {
      if (info.status !== "complete") return;
      void (async () => {
        const session = await loadSession();
        if (session.state !== "recording") return;
        if (session.tabId !== tabId) return;
        await ensureContentInjected(tabId);
      })();
    });
    chrome.tabs.onActivated.addListener((info) => {
      void (async () => {
        const session = await loadSession();
        if (session.state !== "recording") return;
        if (session.tabId !== info.tabId) return;
        await ensureContentInjected(info.tabId);
      })();
    });
  } catch (e) {
    logger.warn("tabs listeners nao disponiveis", e);
  }
  chrome.runtime.onMessage.addListener((rawMessage, sender, sendResponse) => {
    const msgCheck = validateRuntimeMessage(rawMessage);
    if (!msgCheck.ok) {
      logger.warn("mensagem runtime invalida recebida", msgCheck.error);
      sendResponse({ ok: false, error: msgCheck.error });
      return false;
    }
    const message = msgCheck.value;
    (async () => {
      switch (message.type) {
        case "GET_STATE":
          return onGetState();
        case "__GET_LAST_INTERACTION__":
          return onGetLastInteraction();
        case "__GET_LAST_STEP__":
          return onGetLastStep();
        case "__LIST_STEPS__":
          return onListSteps();
        case "__DELETE_STEP__":
          return onDeleteStep(message.payload);
        case "__CLEAR_STEPS__":
          return onClearSteps();
        case "__GET_PROJECT_CONTEXT__":
          return onGetProjectContext();
        case "__SAVE_PROJECT_CONTEXT__":
          return onSaveProjectContext(message.payload);
        case "__NEW_PROJECT_CONTEXT__":
          return onNewProjectContext();
        case "__OPEN_PANEL_BACKGROUND__":
          return onOpenPanelBackground();
        case "__GET_MY_TAB_ID__":
          return onGetMyTabId(sender);
        case "START":
          return onStart();
        case "PAUSE":
          return onSimpleTransition("PAUSE");
        case "RESUME":
          return onSimpleTransition("RESUME");
        case "FINALIZE":
          return onSimpleTransition("FINALIZE");
        case "INCREMENT_STEP":
          return onSimpleTransition("INCREMENT_STEP");
        case "RESET":
          return onReset();
        case "__RECORD_INTERACTION__":
          return onRecordInteraction(message.payload, sender);
        case "__REQUEST_SCREENSHOT__":
          return enqueueScreenshot(() => onRequestScreenshot(message.payload, sender));
        default:
          return {
            ok: false,
            error: `unknown message: ${message.type}`
          };
      }
    })().then(sendResponse).catch((e) => sendResponse({ ok: false, error: e instanceof Error ? e.message : String(e) }));
    return true;
  });
  chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
    const senderUrl = sender.url ?? "";
    const allowed = /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?\//i.test(senderUrl);
    if (!allowed || message?.type !== "HOMOLOG_PANEL_SYNC") {
      sendResponse({ ok: false, error: "Solicitação externa não autorizada." });
      return false;
    }
    (async () => {
      const session = await loadSession();
      if (session.state !== "idle") {
        const projectId = await getOrCreateActiveProjectId();
        await persistRecordingSessionOnIdb(session, { projectId });
        await reconcileSessionEvidence(session, projectId);
        await moveSessionEvidenceToProject(session.sessionId, projectId);
      }
      return Promise.all([
        exportBackup({ includeScreenshots: true }),
        chrome.storage.local.get([STORAGE_KEY_ACTIVE_PROJECT_ID, STORAGE_KEY_ACTIVE_SESSION_ID])
      ]);
    })().then(
      ([backup, active]) => sendResponse({
        ok: true,
        backup,
        activeProjectId: active?.[STORAGE_KEY_ACTIVE_PROJECT_ID],
        activeSessionId: active?.[STORAGE_KEY_ACTIVE_SESSION_ID]
      })
    ).catch(
      (error) => sendResponse({
        ok: false,
        error: error instanceof Error ? error.message : "Não foi possível sincronizar o painel."
      })
    );
    return true;
  });
}
//# sourceMappingURL=index.js.map
